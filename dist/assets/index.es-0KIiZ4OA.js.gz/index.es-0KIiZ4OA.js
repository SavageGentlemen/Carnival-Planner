import { y as eventsExports, z as isHttpUrl, A as safeJsonStringify, B as safeJsonParse, E as formatJsonRpcError, F as parseConnectionError, H as ke, J as Be, K as k, Q as formatJsonRpcResult, R as Kt$1, U as me$1, V as fe$1, Y as Yo, X as Pn, Z as Fe$1, _ as o$1, $ as formatJsonRpcRequest, a0 as Ve$1, a1 as ct$1, a2 as fi, a3 as ii } from "./PassportHome-SJEwmPr3.js";
import { g as getDefaultExportFromCjs, c as commonjsGlobal } from "./vendor-swr-BEHUV5vo.js";
import "./vendor-3d-C6aqP7jv.js";
import "./vendor-maps-DCMhh9kT.js";
import "./index-CXUot43X.js";
import "./vendor-firebase-core-DHwGrt-V.js";
import "./vendor-firebase-data-O6IN0zfq.js";
import "./trophy-hLhL8QOQ.js";
import "./alert-circle-lhG861Pl.js";
import "./bundler-Dmn5v2kr.js";
import "./emotion-unitless.esm-BWDbD2bQ.js";
import "./TypedData-B3RAtJ0b.js";
import "./Address-CuEhN18Y.js";
import "./Authorization-CEwvBCmC.js";
import "./decimals-RuAU2I0v.js";
import "./arweave-BmejQRVS.js";
import "./gift-Biw2Zx2l.js";
import "./star-CGQXWRD_.js";
import "./award-DJfbIRpy.js";
import "./sparkles-BEe8L_dR.js";
var browserPonyfill = { exports: {} };
(function(module, exports$1) {
  var __global__ = typeof globalThis !== "undefined" && globalThis || typeof self !== "undefined" && self || typeof commonjsGlobal !== "undefined" && commonjsGlobal;
  var __globalThis__ = function() {
    function F() {
      this.fetch = false;
      this.DOMException = __global__.DOMException;
    }
    F.prototype = __global__;
    return new F();
  }();
  (function(globalThis2) {
    (function(exports$12) {
      var g2 = typeof globalThis2 !== "undefined" && globalThis2 || typeof self !== "undefined" && self || // eslint-disable-next-line no-undef
      typeof commonjsGlobal !== "undefined" && commonjsGlobal || {};
      var support = {
        searchParams: "URLSearchParams" in g2,
        iterable: "Symbol" in g2 && "iterator" in Symbol,
        blob: "FileReader" in g2 && "Blob" in g2 && function() {
          try {
            new Blob();
            return true;
          } catch (e) {
            return false;
          }
        }(),
        formData: "FormData" in g2,
        arrayBuffer: "ArrayBuffer" in g2
      };
      function isDataView(obj) {
        return obj && DataView.prototype.isPrototypeOf(obj);
      }
      if (support.arrayBuffer) {
        var viewClasses = [
          "[object Int8Array]",
          "[object Uint8Array]",
          "[object Uint8ClampedArray]",
          "[object Int16Array]",
          "[object Uint16Array]",
          "[object Int32Array]",
          "[object Uint32Array]",
          "[object Float32Array]",
          "[object Float64Array]"
        ];
        var isArrayBufferView = ArrayBuffer.isView || function(obj) {
          return obj && viewClasses.indexOf(Object.prototype.toString.call(obj)) > -1;
        };
      }
      function normalizeName(name) {
        if (typeof name !== "string") {
          name = String(name);
        }
        if (/[^a-z0-9\-#$%&'*+.^_`|~!]/i.test(name) || name === "") {
          throw new TypeError('Invalid character in header field name: "' + name + '"');
        }
        return name.toLowerCase();
      }
      function normalizeValue(value) {
        if (typeof value !== "string") {
          value = String(value);
        }
        return value;
      }
      function iteratorFor(items) {
        var iterator = {
          next: function() {
            var value = items.shift();
            return { done: value === void 0, value };
          }
        };
        if (support.iterable) {
          iterator[Symbol.iterator] = function() {
            return iterator;
          };
        }
        return iterator;
      }
      function Headers(headers) {
        this.map = {};
        if (headers instanceof Headers) {
          headers.forEach(function(value, name) {
            this.append(name, value);
          }, this);
        } else if (Array.isArray(headers)) {
          headers.forEach(function(header) {
            if (header.length != 2) {
              throw new TypeError("Headers constructor: expected name/value pair to be length 2, found" + header.length);
            }
            this.append(header[0], header[1]);
          }, this);
        } else if (headers) {
          Object.getOwnPropertyNames(headers).forEach(function(name) {
            this.append(name, headers[name]);
          }, this);
        }
      }
      Headers.prototype.append = function(name, value) {
        name = normalizeName(name);
        value = normalizeValue(value);
        var oldValue = this.map[name];
        this.map[name] = oldValue ? oldValue + ", " + value : value;
      };
      Headers.prototype["delete"] = function(name) {
        delete this.map[normalizeName(name)];
      };
      Headers.prototype.get = function(name) {
        name = normalizeName(name);
        return this.has(name) ? this.map[name] : null;
      };
      Headers.prototype.has = function(name) {
        return this.map.hasOwnProperty(normalizeName(name));
      };
      Headers.prototype.set = function(name, value) {
        this.map[normalizeName(name)] = normalizeValue(value);
      };
      Headers.prototype.forEach = function(callback, thisArg) {
        for (var name in this.map) {
          if (this.map.hasOwnProperty(name)) {
            callback.call(thisArg, this.map[name], name, this);
          }
        }
      };
      Headers.prototype.keys = function() {
        var items = [];
        this.forEach(function(value, name) {
          items.push(name);
        });
        return iteratorFor(items);
      };
      Headers.prototype.values = function() {
        var items = [];
        this.forEach(function(value) {
          items.push(value);
        });
        return iteratorFor(items);
      };
      Headers.prototype.entries = function() {
        var items = [];
        this.forEach(function(value, name) {
          items.push([name, value]);
        });
        return iteratorFor(items);
      };
      if (support.iterable) {
        Headers.prototype[Symbol.iterator] = Headers.prototype.entries;
      }
      function consumed(body) {
        if (body._noBody) return;
        if (body.bodyUsed) {
          return Promise.reject(new TypeError("Already read"));
        }
        body.bodyUsed = true;
      }
      function fileReaderReady(reader) {
        return new Promise(function(resolve, reject) {
          reader.onload = function() {
            resolve(reader.result);
          };
          reader.onerror = function() {
            reject(reader.error);
          };
        });
      }
      function readBlobAsArrayBuffer(blob) {
        var reader = new FileReader();
        var promise = fileReaderReady(reader);
        reader.readAsArrayBuffer(blob);
        return promise;
      }
      function readBlobAsText(blob) {
        var reader = new FileReader();
        var promise = fileReaderReady(reader);
        var match = /charset=([A-Za-z0-9_-]+)/.exec(blob.type);
        var encoding = match ? match[1] : "utf-8";
        reader.readAsText(blob, encoding);
        return promise;
      }
      function readArrayBufferAsText(buf) {
        var view = new Uint8Array(buf);
        var chars = new Array(view.length);
        for (var i = 0; i < view.length; i++) {
          chars[i] = String.fromCharCode(view[i]);
        }
        return chars.join("");
      }
      function bufferClone(buf) {
        if (buf.slice) {
          return buf.slice(0);
        } else {
          var view = new Uint8Array(buf.byteLength);
          view.set(new Uint8Array(buf));
          return view.buffer;
        }
      }
      function Body() {
        this.bodyUsed = false;
        this._initBody = function(body) {
          this.bodyUsed = this.bodyUsed;
          this._bodyInit = body;
          if (!body) {
            this._noBody = true;
            this._bodyText = "";
          } else if (typeof body === "string") {
            this._bodyText = body;
          } else if (support.blob && Blob.prototype.isPrototypeOf(body)) {
            this._bodyBlob = body;
          } else if (support.formData && FormData.prototype.isPrototypeOf(body)) {
            this._bodyFormData = body;
          } else if (support.searchParams && URLSearchParams.prototype.isPrototypeOf(body)) {
            this._bodyText = body.toString();
          } else if (support.arrayBuffer && support.blob && isDataView(body)) {
            this._bodyArrayBuffer = bufferClone(body.buffer);
            this._bodyInit = new Blob([this._bodyArrayBuffer]);
          } else if (support.arrayBuffer && (ArrayBuffer.prototype.isPrototypeOf(body) || isArrayBufferView(body))) {
            this._bodyArrayBuffer = bufferClone(body);
          } else {
            this._bodyText = body = Object.prototype.toString.call(body);
          }
          if (!this.headers.get("content-type")) {
            if (typeof body === "string") {
              this.headers.set("content-type", "text/plain;charset=UTF-8");
            } else if (this._bodyBlob && this._bodyBlob.type) {
              this.headers.set("content-type", this._bodyBlob.type);
            } else if (support.searchParams && URLSearchParams.prototype.isPrototypeOf(body)) {
              this.headers.set("content-type", "application/x-www-form-urlencoded;charset=UTF-8");
            }
          }
        };
        if (support.blob) {
          this.blob = function() {
            var rejected = consumed(this);
            if (rejected) {
              return rejected;
            }
            if (this._bodyBlob) {
              return Promise.resolve(this._bodyBlob);
            } else if (this._bodyArrayBuffer) {
              return Promise.resolve(new Blob([this._bodyArrayBuffer]));
            } else if (this._bodyFormData) {
              throw new Error("could not read FormData body as blob");
            } else {
              return Promise.resolve(new Blob([this._bodyText]));
            }
          };
        }
        this.arrayBuffer = function() {
          if (this._bodyArrayBuffer) {
            var isConsumed = consumed(this);
            if (isConsumed) {
              return isConsumed;
            } else if (ArrayBuffer.isView(this._bodyArrayBuffer)) {
              return Promise.resolve(
                this._bodyArrayBuffer.buffer.slice(
                  this._bodyArrayBuffer.byteOffset,
                  this._bodyArrayBuffer.byteOffset + this._bodyArrayBuffer.byteLength
                )
              );
            } else {
              return Promise.resolve(this._bodyArrayBuffer);
            }
          } else if (support.blob) {
            return this.blob().then(readBlobAsArrayBuffer);
          } else {
            throw new Error("could not read as ArrayBuffer");
          }
        };
        this.text = function() {
          var rejected = consumed(this);
          if (rejected) {
            return rejected;
          }
          if (this._bodyBlob) {
            return readBlobAsText(this._bodyBlob);
          } else if (this._bodyArrayBuffer) {
            return Promise.resolve(readArrayBufferAsText(this._bodyArrayBuffer));
          } else if (this._bodyFormData) {
            throw new Error("could not read FormData body as text");
          } else {
            return Promise.resolve(this._bodyText);
          }
        };
        if (support.formData) {
          this.formData = function() {
            return this.text().then(decode);
          };
        }
        this.json = function() {
          return this.text().then(JSON.parse);
        };
        return this;
      }
      var methods = ["CONNECT", "DELETE", "GET", "HEAD", "OPTIONS", "PATCH", "POST", "PUT", "TRACE"];
      function normalizeMethod(method) {
        var upcased = method.toUpperCase();
        return methods.indexOf(upcased) > -1 ? upcased : method;
      }
      function Request(input, options) {
        if (!(this instanceof Request)) {
          throw new TypeError('Please use the "new" operator, this DOM object constructor cannot be called as a function.');
        }
        options = options || {};
        var body = options.body;
        if (input instanceof Request) {
          if (input.bodyUsed) {
            throw new TypeError("Already read");
          }
          this.url = input.url;
          this.credentials = input.credentials;
          if (!options.headers) {
            this.headers = new Headers(input.headers);
          }
          this.method = input.method;
          this.mode = input.mode;
          this.signal = input.signal;
          if (!body && input._bodyInit != null) {
            body = input._bodyInit;
            input.bodyUsed = true;
          }
        } else {
          this.url = String(input);
        }
        this.credentials = options.credentials || this.credentials || "same-origin";
        if (options.headers || !this.headers) {
          this.headers = new Headers(options.headers);
        }
        this.method = normalizeMethod(options.method || this.method || "GET");
        this.mode = options.mode || this.mode || null;
        this.signal = options.signal || this.signal || function() {
          if ("AbortController" in g2) {
            var ctrl = new AbortController();
            return ctrl.signal;
          }
        }();
        this.referrer = null;
        if ((this.method === "GET" || this.method === "HEAD") && body) {
          throw new TypeError("Body not allowed for GET or HEAD requests");
        }
        this._initBody(body);
        if (this.method === "GET" || this.method === "HEAD") {
          if (options.cache === "no-store" || options.cache === "no-cache") {
            var reParamSearch = /([?&])_=[^&]*/;
            if (reParamSearch.test(this.url)) {
              this.url = this.url.replace(reParamSearch, "$1_=" + (/* @__PURE__ */ new Date()).getTime());
            } else {
              var reQueryString = /\?/;
              this.url += (reQueryString.test(this.url) ? "&" : "?") + "_=" + (/* @__PURE__ */ new Date()).getTime();
            }
          }
        }
      }
      Request.prototype.clone = function() {
        return new Request(this, { body: this._bodyInit });
      };
      function decode(body) {
        var form = new FormData();
        body.trim().split("&").forEach(function(bytes) {
          if (bytes) {
            var split = bytes.split("=");
            var name = split.shift().replace(/\+/g, " ");
            var value = split.join("=").replace(/\+/g, " ");
            form.append(decodeURIComponent(name), decodeURIComponent(value));
          }
        });
        return form;
      }
      function parseHeaders(rawHeaders) {
        var headers = new Headers();
        var preProcessedHeaders = rawHeaders.replace(/\r?\n[\t ]+/g, " ");
        preProcessedHeaders.split("\r").map(function(header) {
          return header.indexOf("\n") === 0 ? header.substr(1, header.length) : header;
        }).forEach(function(line) {
          var parts = line.split(":");
          var key = parts.shift().trim();
          if (key) {
            var value = parts.join(":").trim();
            try {
              headers.append(key, value);
            } catch (error) {
              console.warn("Response " + error.message);
            }
          }
        });
        return headers;
      }
      Body.call(Request.prototype);
      function Response(bodyInit, options) {
        if (!(this instanceof Response)) {
          throw new TypeError('Please use the "new" operator, this DOM object constructor cannot be called as a function.');
        }
        if (!options) {
          options = {};
        }
        this.type = "default";
        this.status = options.status === void 0 ? 200 : options.status;
        if (this.status < 200 || this.status > 599) {
          throw new RangeError("Failed to construct 'Response': The status provided (0) is outside the range [200, 599].");
        }
        this.ok = this.status >= 200 && this.status < 300;
        this.statusText = options.statusText === void 0 ? "" : "" + options.statusText;
        this.headers = new Headers(options.headers);
        this.url = options.url || "";
        this._initBody(bodyInit);
      }
      Body.call(Response.prototype);
      Response.prototype.clone = function() {
        return new Response(this._bodyInit, {
          status: this.status,
          statusText: this.statusText,
          headers: new Headers(this.headers),
          url: this.url
        });
      };
      Response.error = function() {
        var response = new Response(null, { status: 200, statusText: "" });
        response.ok = false;
        response.status = 0;
        response.type = "error";
        return response;
      };
      var redirectStatuses = [301, 302, 303, 307, 308];
      Response.redirect = function(url, status) {
        if (redirectStatuses.indexOf(status) === -1) {
          throw new RangeError("Invalid status code");
        }
        return new Response(null, { status, headers: { location: url } });
      };
      exports$12.DOMException = g2.DOMException;
      try {
        new exports$12.DOMException();
      } catch (err) {
        exports$12.DOMException = function(message, name) {
          this.message = message;
          this.name = name;
          var error = Error(message);
          this.stack = error.stack;
        };
        exports$12.DOMException.prototype = Object.create(Error.prototype);
        exports$12.DOMException.prototype.constructor = exports$12.DOMException;
      }
      function fetch2(input, init) {
        return new Promise(function(resolve, reject) {
          var request = new Request(input, init);
          if (request.signal && request.signal.aborted) {
            return reject(new exports$12.DOMException("Aborted", "AbortError"));
          }
          var xhr = new XMLHttpRequest();
          function abortXhr() {
            xhr.abort();
          }
          xhr.onload = function() {
            var options = {
              statusText: xhr.statusText,
              headers: parseHeaders(xhr.getAllResponseHeaders() || "")
            };
            if (request.url.indexOf("file://") === 0 && (xhr.status < 200 || xhr.status > 599)) {
              options.status = 200;
            } else {
              options.status = xhr.status;
            }
            options.url = "responseURL" in xhr ? xhr.responseURL : options.headers.get("X-Request-URL");
            var body = "response" in xhr ? xhr.response : xhr.responseText;
            setTimeout(function() {
              resolve(new Response(body, options));
            }, 0);
          };
          xhr.onerror = function() {
            setTimeout(function() {
              reject(new TypeError("Network request failed"));
            }, 0);
          };
          xhr.ontimeout = function() {
            setTimeout(function() {
              reject(new TypeError("Network request timed out"));
            }, 0);
          };
          xhr.onabort = function() {
            setTimeout(function() {
              reject(new exports$12.DOMException("Aborted", "AbortError"));
            }, 0);
          };
          function fixUrl(url) {
            try {
              return url === "" && g2.location.href ? g2.location.href : url;
            } catch (e) {
              return url;
            }
          }
          xhr.open(request.method, fixUrl(request.url), true);
          if (request.credentials === "include") {
            xhr.withCredentials = true;
          } else if (request.credentials === "omit") {
            xhr.withCredentials = false;
          }
          if ("responseType" in xhr) {
            if (support.blob) {
              xhr.responseType = "blob";
            } else if (support.arrayBuffer) {
              xhr.responseType = "arraybuffer";
            }
          }
          if (init && typeof init.headers === "object" && !(init.headers instanceof Headers || g2.Headers && init.headers instanceof g2.Headers)) {
            var names = [];
            Object.getOwnPropertyNames(init.headers).forEach(function(name) {
              names.push(normalizeName(name));
              xhr.setRequestHeader(name, normalizeValue(init.headers[name]));
            });
            request.headers.forEach(function(value, name) {
              if (names.indexOf(name) === -1) {
                xhr.setRequestHeader(name, value);
              }
            });
          } else {
            request.headers.forEach(function(value, name) {
              xhr.setRequestHeader(name, value);
            });
          }
          if (request.signal) {
            request.signal.addEventListener("abort", abortXhr);
            xhr.onreadystatechange = function() {
              if (xhr.readyState === 4) {
                request.signal.removeEventListener("abort", abortXhr);
              }
            };
          }
          xhr.send(typeof request._bodyInit === "undefined" ? null : request._bodyInit);
        });
      }
      fetch2.polyfill = true;
      if (!g2.fetch) {
        g2.fetch = fetch2;
        g2.Headers = Headers;
        g2.Request = Request;
        g2.Response = Response;
      }
      exports$12.Headers = Headers;
      exports$12.Request = Request;
      exports$12.Response = Response;
      exports$12.fetch = fetch2;
      Object.defineProperty(exports$12, "__esModule", { value: true });
      return exports$12;
    })({});
  })(__globalThis__);
  __globalThis__.fetch.ponyfill = true;
  delete __globalThis__.fetch.polyfill;
  var ctx = __global__.fetch ? __global__ : __globalThis__;
  exports$1 = ctx.fetch;
  exports$1.default = ctx.fetch;
  exports$1.fetch = ctx.fetch;
  exports$1.Headers = ctx.Headers;
  exports$1.Request = ctx.Request;
  exports$1.Response = ctx.Response;
  module.exports = exports$1;
})(browserPonyfill, browserPonyfill.exports);
var browserPonyfillExports = browserPonyfill.exports;
const o = /* @__PURE__ */ getDefaultExportFromCjs(browserPonyfillExports);
var P = Object.defineProperty, w = Object.defineProperties, E$1 = Object.getOwnPropertyDescriptors, c = Object.getOwnPropertySymbols, L$1 = Object.prototype.hasOwnProperty, O$1 = Object.prototype.propertyIsEnumerable, l = (r, t, e) => t in r ? P(r, t, { enumerable: true, configurable: true, writable: true, value: e }) : r[t] = e, p = (r, t) => {
  for (var e in t || (t = {})) L$1.call(t, e) && l(r, e, t[e]);
  if (c) for (var e of c(t)) O$1.call(t, e) && l(r, e, t[e]);
  return r;
}, v$1 = (r, t) => w(r, E$1(t));
const j$1 = { Accept: "application/json", "Content-Type": "application/json" }, T$1 = "POST", d = { headers: j$1, method: T$1 }, g = 10;
let f$1 = class f {
  constructor(t, e = false) {
    if (this.url = t, this.disableProviderPing = e, this.events = new eventsExports.EventEmitter(), this.isAvailable = false, this.registering = false, !isHttpUrl(t)) throw new Error(`Provided URL is not compatible with HTTP connection: ${t}`);
    this.url = t, this.disableProviderPing = e;
  }
  get connected() {
    return this.isAvailable;
  }
  get connecting() {
    return this.registering;
  }
  on(t, e) {
    this.events.on(t, e);
  }
  once(t, e) {
    this.events.once(t, e);
  }
  off(t, e) {
    this.events.off(t, e);
  }
  removeListener(t, e) {
    this.events.removeListener(t, e);
  }
  async open(t = this.url) {
    await this.register(t);
  }
  async close() {
    if (!this.isAvailable) throw new Error("Connection already closed");
    this.onClose();
  }
  async send(t) {
    this.isAvailable || await this.register();
    try {
      const e = safeJsonStringify(t), s = await (await o(this.url, v$1(p({}, d), { body: e }))).json();
      this.onPayload({ data: s });
    } catch (e) {
      this.onError(t.id, e);
    }
  }
  async register(t = this.url) {
    if (!isHttpUrl(t)) throw new Error(`Provided URL is not compatible with HTTP connection: ${t}`);
    if (this.registering) {
      const e = this.events.getMaxListeners();
      return (this.events.listenerCount("register_error") >= e || this.events.listenerCount("open") >= e) && this.events.setMaxListeners(e + 1), new Promise((s, i) => {
        this.events.once("register_error", (n) => {
          this.resetMaxListeners(), i(n);
        }), this.events.once("open", () => {
          if (this.resetMaxListeners(), typeof this.isAvailable > "u") return i(new Error("HTTP connection is missing or invalid"));
          s();
        });
      });
    }
    this.url = t, this.registering = true;
    try {
      if (!this.disableProviderPing) {
        const e = safeJsonStringify({ id: 1, jsonrpc: "2.0", method: "test", params: [] });
        await o(t, v$1(p({}, d), { body: e }));
      }
      this.onOpen();
    } catch (e) {
      const s = this.parseError(e);
      throw this.events.emit("register_error", s), this.onClose(), s;
    }
  }
  onOpen() {
    this.isAvailable = true, this.registering = false, this.events.emit("open");
  }
  onClose() {
    this.isAvailable = false, this.registering = false, this.events.emit("close");
  }
  onPayload(t) {
    if (typeof t.data > "u") return;
    const e = typeof t.data == "string" ? safeJsonParse(t.data) : t.data;
    this.events.emit("payload", e);
  }
  onError(t, e) {
    const s = this.parseError(e), i = s.message || s.toString(), n = formatJsonRpcError(t, i);
    this.events.emit("payload", n);
  }
  parseError(t, e = this.url) {
    return parseConnectionError(t, e, "HTTP");
  }
  resetMaxListeners() {
    this.events.getMaxListeners() > g && this.events.setMaxListeners(g);
  }
};
const pe = "error", We = "wss://relay.walletconnect.org", Ke = "wc", Ve = "universal_provider", x = `${Ke}@2:${Ve}:`, de = "https://rpc.walletconnect.org/v1/", ue = "generic", Ye = `${de}bundler`, $ = "call_status", Xe = 86400, m = { DEFAULT_CHAIN_CHANGED: "default_chain_changed" };
function K(s) {
  return s == null || typeof s != "object" && typeof s != "function";
}
function le(s) {
  return Object.getOwnPropertySymbols(s).filter((e) => Object.prototype.propertyIsEnumerable.call(s, e));
}
function fe(s) {
  return s == null ? s === void 0 ? "[object Undefined]" : "[object Null]" : Object.prototype.toString.call(s);
}
const Qe = "[object RegExp]", me = "[object String]", ve = "[object Number]", ge = "[object Boolean]", Pe = "[object Arguments]", Ze = "[object Symbol]", Te = "[object Date]", et = "[object Map]", tt = "[object Set]", st = "[object Array]", it = "[object ArrayBuffer]", rt = "[object Object]", nt = "[object DataView]", at = "[object Uint8Array]", ct = "[object Uint8ClampedArray]", ot = "[object Uint16Array]", ht = "[object Uint32Array]", pt = "[object Int8Array]", dt = "[object Int16Array]", ut = "[object Int32Array]", lt = "[object Float32Array]", ft = "[object Float64Array]";
function V(s) {
  return ArrayBuffer.isView(s) && !(s instanceof DataView);
}
function mt(s, e) {
  return O(s, void 0, s, /* @__PURE__ */ new Map(), e);
}
function O(s, e, t, i = /* @__PURE__ */ new Map(), n = void 0) {
  const a = n?.(s, e, t, i);
  if (a != null) return a;
  if (K(s)) return s;
  if (i.has(s)) return i.get(s);
  if (Array.isArray(s)) {
    const r = new Array(s.length);
    i.set(s, r);
    for (let c2 = 0; c2 < s.length; c2++) r[c2] = O(s[c2], c2, t, i, n);
    return Object.hasOwn(s, "index") && (r.index = s.index), Object.hasOwn(s, "input") && (r.input = s.input), r;
  }
  if (s instanceof Date) return new Date(s.getTime());
  if (s instanceof RegExp) {
    const r = new RegExp(s.source, s.flags);
    return r.lastIndex = s.lastIndex, r;
  }
  if (s instanceof Map) {
    const r = /* @__PURE__ */ new Map();
    i.set(s, r);
    for (const [c2, o2] of s) r.set(c2, O(o2, c2, t, i, n));
    return r;
  }
  if (s instanceof Set) {
    const r = /* @__PURE__ */ new Set();
    i.set(s, r);
    for (const c2 of s) r.add(O(c2, void 0, t, i, n));
    return r;
  }
  if (typeof Buffer < "u" && Buffer.isBuffer(s)) return s.subarray();
  if (V(s)) {
    const r = new (Object.getPrototypeOf(s)).constructor(s.length);
    i.set(s, r);
    for (let c2 = 0; c2 < s.length; c2++) r[c2] = O(s[c2], c2, t, i, n);
    return r;
  }
  if (s instanceof ArrayBuffer || typeof SharedArrayBuffer < "u" && s instanceof SharedArrayBuffer) return s.slice(0);
  if (s instanceof DataView) {
    const r = new DataView(s.buffer.slice(0), s.byteOffset, s.byteLength);
    return i.set(s, r), y(r, s, t, i, n), r;
  }
  if (typeof File < "u" && s instanceof File) {
    const r = new File([s], s.name, { type: s.type });
    return i.set(s, r), y(r, s, t, i, n), r;
  }
  if (s instanceof Blob) {
    const r = new Blob([s], { type: s.type });
    return i.set(s, r), y(r, s, t, i, n), r;
  }
  if (s instanceof Error) {
    const r = new s.constructor();
    return i.set(s, r), r.message = s.message, r.name = s.name, r.stack = s.stack, r.cause = s.cause, y(r, s, t, i, n), r;
  }
  if (typeof s == "object" && vt(s)) {
    const r = Object.create(Object.getPrototypeOf(s));
    return i.set(s, r), y(r, s, t, i, n), r;
  }
  return s;
}
function y(s, e, t = s, i, n) {
  const a = [...Object.keys(e), ...le(e)];
  for (let r = 0; r < a.length; r++) {
    const c2 = a[r], o2 = Object.getOwnPropertyDescriptor(s, c2);
    (o2 == null || o2.writable) && (s[c2] = O(e[c2], c2, t, i, n));
  }
}
function vt(s) {
  switch (fe(s)) {
    case Pe:
    case st:
    case it:
    case nt:
    case ge:
    case Te:
    case lt:
    case ft:
    case pt:
    case dt:
    case ut:
    case et:
    case ve:
    case rt:
    case Qe:
    case tt:
    case me:
    case Ze:
    case at:
    case ct:
    case ot:
    case ht:
      return true;
    default:
      return false;
  }
}
function gt(s, e) {
  return mt(s, (t, i, n, a) => {
    if (typeof s == "object") switch (Object.prototype.toString.call(s)) {
      case ve:
      case me:
      case ge: {
        const c2 = new s.constructor(s?.valueOf());
        return y(c2, s), c2;
      }
      case Pe: {
        const c2 = {};
        return y(c2, s), c2.length = s.length, c2[Symbol.iterator] = s[Symbol.iterator], c2;
      }
      default:
        return;
    }
  });
}
function we(s) {
  return gt(s);
}
function ye(s) {
  return s !== null && typeof s == "object" && fe(s) === "[object Arguments]";
}
function be(s) {
  return typeof s == "object" && s !== null;
}
function Pt() {
}
function wt(s) {
  return V(s);
}
function yt(s) {
  if (typeof s != "object" || s == null) return false;
  if (Object.getPrototypeOf(s) === null) return true;
  if (Object.prototype.toString.call(s) !== "[object Object]") {
    const t = s[Symbol.toStringTag];
    return t == null || !Object.getOwnPropertyDescriptor(s, Symbol.toStringTag)?.writable ? false : s.toString() === `[object ${t}]`;
  }
  let e = s;
  for (; Object.getPrototypeOf(e) !== null; ) e = Object.getPrototypeOf(e);
  return Object.getPrototypeOf(s) === e;
}
function bt(s) {
  if (K(s)) return s;
  if (Array.isArray(s) || V(s) || s instanceof ArrayBuffer || typeof SharedArrayBuffer < "u" && s instanceof SharedArrayBuffer) return s.slice(0);
  const e = Object.getPrototypeOf(s), t = e.constructor;
  if (s instanceof Date || s instanceof Map || s instanceof Set) return new t(s);
  if (s instanceof RegExp) {
    const i = new t(s);
    return i.lastIndex = s.lastIndex, i;
  }
  if (s instanceof DataView) return new t(s.buffer.slice(0));
  if (s instanceof Error) {
    const i = new t(s.message);
    return i.stack = s.stack, i.name = s.name, i.cause = s.cause, i;
  }
  if (typeof File < "u" && s instanceof File) return new t([s], s.name, { type: s.type, lastModified: s.lastModified });
  if (typeof s == "object") {
    const i = Object.create(e);
    return Object.assign(i, s);
  }
  return s;
}
function It(s, ...e) {
  const t = e.slice(0, -1), i = e[e.length - 1];
  let n = s;
  for (let a = 0; a < t.length; a++) {
    const r = t[a];
    n = L(n, r, i, /* @__PURE__ */ new Map());
  }
  return n;
}
function L(s, e, t, i) {
  if (K(s) && (s = Object(s)), e == null || typeof e != "object") return s;
  if (i.has(e)) return bt(i.get(e));
  if (i.set(e, s), Array.isArray(e)) {
    e = e.slice();
    for (let a = 0; a < e.length; a++) e[a] = e[a] ?? void 0;
  }
  const n = [...Object.keys(e), ...le(e)];
  for (let a = 0; a < n.length; a++) {
    const r = n[a];
    let c2 = e[r], o2 = s[r];
    if (ye(c2) && (c2 = { ...c2 }), ye(o2) && (o2 = { ...o2 }), typeof Buffer < "u" && Buffer.isBuffer(c2) && (c2 = we(c2)), Array.isArray(c2)) if (typeof o2 == "object" && o2 != null) {
      const u = [], p2 = Reflect.ownKeys(o2);
      for (let w2 = 0; w2 < p2.length; w2++) {
        const l2 = p2[w2];
        u[l2] = o2[l2];
      }
      o2 = u;
    } else o2 = [];
    const d2 = t(o2, c2, r, s, e, i);
    d2 != null ? s[r] = d2 : Array.isArray(c2) || be(o2) && be(c2) ? s[r] = L(o2, c2, t, i) : o2 == null && yt(c2) ? s[r] = L({}, c2, t, i) : o2 == null && wt(c2) ? s[r] = we(c2) : (o2 === void 0 || c2 !== void 0) && (s[r] = c2);
  }
  return s;
}
function $t(s, ...e) {
  return It(s, ...e, Pt);
}
var Ot = Object.defineProperty, Ct = Object.defineProperties, At = Object.getOwnPropertyDescriptors, Ie = Object.getOwnPropertySymbols, Et = Object.prototype.hasOwnProperty, Ht = Object.prototype.propertyIsEnumerable, $e = (s, e, t) => e in s ? Ot(s, e, { enumerable: true, configurable: true, writable: true, value: t }) : s[e] = t, M = (s, e) => {
  for (var t in e || (e = {})) Et.call(e, t) && $e(s, t, e[t]);
  if (Ie) for (var t of Ie(e)) Ht.call(e, t) && $e(s, t, e[t]);
  return s;
}, St = (s, e) => Ct(s, At(e));
function f2(s, e, t) {
  var i;
  const n = Fe$1(s);
  return ((i = e.rpcMap) == null ? void 0 : i[n.reference]) || `${de}?chainId=${n.namespace}:${n.reference}&projectId=${t}`;
}
function b(s) {
  return s.includes(":") ? s.split(":")[1] : s;
}
function Oe(s) {
  return s.map((e) => `${e.split(":")[0]}:${e.split(":")[1]}`);
}
function Nt(s, e) {
  const t = Object.keys(e.namespaces).filter((n) => n.includes(s));
  if (!t.length) return [];
  const i = [];
  return t.forEach((n) => {
    const a = e.namespaces[n].accounts;
    i.push(...a);
  }), i;
}
function Ce(s) {
  return Object.fromEntries(Object.entries(s).filter(([e, t]) => {
    var i, n;
    return ((i = t?.chains) == null ? void 0 : i.length) && ((n = t?.chains) == null ? void 0 : n.length) > 0;
  }));
}
function B(s = {}, e = {}) {
  const t = Ce(Ae(s)), i = Ce(Ae(e));
  return $t(t, i);
}
function Ae(s) {
  var e, t, i, n, a;
  const r = {};
  if (!Ve$1(s)) return r;
  for (const [c2, o2] of Object.entries(s)) {
    const d2 = Pn(c2) ? [c2] : o2.chains, u = o2.methods || [], p2 = o2.events || [], w2 = o2.rpcMap || {}, l2 = Yo(c2);
    r[l2] = St(M(M({}, r[l2]), o2), { chains: ct$1(d2, (e = r[l2]) == null ? void 0 : e.chains), methods: ct$1(u, (t = r[l2]) == null ? void 0 : t.methods), events: ct$1(p2, (i = r[l2]) == null ? void 0 : i.events) }), (Ve$1(w2) || Ve$1(((n = r[l2]) == null ? void 0 : n.rpcMap) || {})) && (r[l2].rpcMap = M(M({}, w2), (a = r[l2]) == null ? void 0 : a.rpcMap));
  }
  return r;
}
function Ee(s) {
  return s.includes(":") ? s.split(":")[2] : s;
}
function He(s) {
  const e = {};
  for (const [t, i] of Object.entries(s)) {
    const n = i.methods || [], a = i.events || [], r = i.accounts || [], c2 = Pn(t) ? [t] : i.chains ? i.chains : Oe(i.accounts);
    e[t] = { chains: c2, methods: n, events: a, accounts: r };
  }
  return e;
}
function Y(s) {
  return typeof s == "number" ? s : s.includes("0x") ? parseInt(s, 16) : (s = s.includes(":") ? s.split(":")[1] : s, isNaN(Number(s)) ? s : Number(s));
}
function qt(s) {
  try {
    const e = JSON.parse(s);
    return typeof e == "object" && e !== null && !Array.isArray(e);
  } catch {
    return false;
  }
}
const Se = {}, h = (s) => Se[s], X = (s, e) => {
  Se[s] = e;
};
var Dt = Object.defineProperty, Ne = Object.getOwnPropertySymbols, jt = Object.prototype.hasOwnProperty, Rt = Object.prototype.propertyIsEnumerable, qe = (s, e, t) => e in s ? Dt(s, e, { enumerable: true, configurable: true, writable: true, value: t }) : s[e] = t, De = (s, e) => {
  for (var t in e || (e = {})) jt.call(e, t) && qe(s, t, e[t]);
  if (Ne) for (var t of Ne(e)) Rt.call(e, t) && qe(s, t, e[t]);
  return s;
};
const je = "eip155", _t = ["atomic", "flow-control", "paymasterService", "sessionKeys", "auxiliaryFunds"], Ft = (s) => s && s.startsWith("0x") ? BigInt(s).toString(10) : s, Q = (s) => s && s.startsWith("0x") ? s : `0x${BigInt(s).toString(16)}`, Re = (s) => Object.keys(s).filter((e) => _t.includes(e)).reduce((e, t) => (e[t] = Ut(s[t]), e), {}), Ut = (s) => typeof s == "string" && qt(s) ? JSON.parse(s) : s, xt = (s, e, t) => {
  const { sessionProperties: i = {}, scopedProperties: n = {} } = s, a = {};
  if (!Ve$1(n) && !Ve$1(i)) return;
  const r = Re(i);
  for (const c2 of t) {
    const o2 = Ft(c2);
    if (!o2) continue;
    a[Q(o2)] = r;
    const d2 = n?.[`${je}:${o2}`];
    if (d2) {
      const u = d2?.[`${je}:${o2}:${e}`];
      a[Q(o2)] = De(De({}, a[Q(o2)]), Re(u || d2));
    }
  }
  for (const [c2, o2] of Object.entries(a)) Object.keys(o2).length === 0 && delete a[c2];
  return Object.keys(a).length > 0 ? a : void 0;
};
var Lt = Object.defineProperty, Mt = (s, e, t) => e in s ? Lt(s, e, { enumerable: true, configurable: true, writable: true, value: t }) : s[e] = t, Bt = (s, e, t) => Mt(s, e + "", t);
let Z;
class re {
  constructor(e) {
    Bt(this, "storage"), this.storage = e;
  }
  async getItem(e) {
    return await this.storage.getItem(e);
  }
  async setItem(e, t) {
    return await this.storage.setItem(e, t);
  }
  async removeItem(e) {
    return await this.storage.removeItem(e);
  }
  static getStorage(e) {
    return Z || (Z = new re(e)), Z;
  }
}
var Gt = Object.defineProperty, Jt = Object.defineProperties, zt = Object.getOwnPropertyDescriptors, _e = Object.getOwnPropertySymbols, kt = Object.prototype.hasOwnProperty, Wt = Object.prototype.propertyIsEnumerable, Fe = (s, e, t) => e in s ? Gt(s, e, { enumerable: true, configurable: true, writable: true, value: t }) : s[e] = t, Kt = (s, e) => {
  for (var t in e || (e = {})) kt.call(e, t) && Fe(s, t, e[t]);
  if (_e) for (var t of _e(e)) Wt.call(e, t) && Fe(s, t, e[t]);
  return s;
}, Vt = (s, e) => Jt(s, zt(e));
async function Yt(s, e) {
  const t = Fe$1(s.result.capabilities.caip345.caip2), i = s.result.capabilities.caip345.transactionHashes, n = await Promise.allSettled(i.map((p2) => Xt(t.reference, p2, e))), a = n.filter((p2) => p2.status === "fulfilled").map((p2) => p2.value).filter((p2) => p2);
  n.filter((p2) => p2.status === "rejected").forEach((p2) => console.warn("Failed to fetch transaction receipt:", p2.reason));
  const r = !a.length || a.some((p2) => !p2), c2 = a.every((p2) => p2?.status === "0x1"), o2 = a.every((p2) => p2?.status === "0x0"), d2 = a.some((p2) => p2?.status === "0x0");
  let u;
  return r ? u = 100 : c2 ? u = 200 : o2 ? u = 500 : d2 && (u = 600), { id: s.result.id, version: s.request.version, atomic: s.request.atomicRequired, chainId: s.request.chainId, capabilities: s.result.capabilities, receipts: a, status: u };
}
async function Xt(s, e, t) {
  return await t(parseInt(s)).request(formatJsonRpcRequest("eth_getTransactionReceipt", [e]));
}
async function Qt({ sendCalls: s, storage: e }) {
  const t = await e.getItem($);
  await e.setItem($, Vt(Kt({}, t), { [s.result.id]: { request: s.request, result: s.result, expiry: ii(Xe) } }));
}
async function Zt({ resultId: s, storage: e }) {
  const t = await e.getItem($);
  if (t) {
    delete t[s], await e.setItem($, t);
    for (const i in t) fi(t[i].expiry) && delete t[i];
    await e.setItem($, t);
  }
}
async function Tt({ resultId: s, storage: e }) {
  const t = await e.getItem($), i = t?.[s];
  if (i && !fi(i.expiry)) return i;
  await Zt({ resultId: s, storage: e });
}
var es = Object.defineProperty, ts = (s, e, t) => e in s ? es(s, e, { enumerable: true, configurable: true, writable: true, value: t }) : s[e] = t, C = (s, e, t) => ts(s, typeof e != "symbol" ? e + "" : e, t);
class ss {
  constructor(e) {
    C(this, "name", "polkadot"), C(this, "client"), C(this, "httpProviders"), C(this, "events"), C(this, "namespace"), C(this, "chainId"), this.namespace = e.namespace, this.events = h("events"), this.client = h("client"), this.chainId = this.getDefaultChain(), this.httpProviders = this.createHttpProviders();
  }
  updateNamespace(e) {
    this.namespace = Object.assign(this.namespace, e);
  }
  requestAccounts() {
    return this.getAccounts();
  }
  getDefaultChain() {
    if (this.chainId) return this.chainId;
    if (this.namespace.defaultChain) return this.namespace.defaultChain;
    const e = this.namespace.chains[0];
    if (!e) throw new Error("ChainId not found");
    return e.split(":")[1];
  }
  request(e) {
    return this.namespace.methods.includes(e.request.method) ? this.client.request(e) : this.getHttpProvider().request(e.request);
  }
  setDefaultChain(e, t) {
    this.httpProviders[e] || this.setHttpProvider(e, t), this.chainId = e, this.events.emit(m.DEFAULT_CHAIN_CHANGED, `${this.name}:${e}`);
  }
  getAccounts() {
    const e = this.namespace.accounts;
    return e ? e.filter((t) => t.split(":")[1] === this.chainId.toString()).map((t) => t.split(":")[2]) || [] : [];
  }
  createHttpProviders() {
    const e = {};
    return this.namespace.chains.forEach((t) => {
      var i;
      const n = b(t);
      e[n] = this.createHttpProvider(n, (i = this.namespace.rpcMap) == null ? void 0 : i[t]);
    }), e;
  }
  getHttpProvider() {
    const e = `${this.name}:${this.chainId}`, t = this.httpProviders[e];
    if (typeof t > "u") throw new Error(`JSON-RPC provider for ${e} not found`);
    return t;
  }
  setHttpProvider(e, t) {
    const i = this.createHttpProvider(e, t);
    i && (this.httpProviders[e] = i);
  }
  createHttpProvider(e, t) {
    const i = t || f2(e, this.namespace, this.client.core.projectId);
    if (!i) throw new Error(`No RPC url provided for chainId: ${e}`);
    return new o$1(new f$1(i, h("disableProviderPing")));
  }
}
var is = Object.defineProperty, rs = Object.defineProperties, ns = Object.getOwnPropertyDescriptors, Ue = Object.getOwnPropertySymbols, as = Object.prototype.hasOwnProperty, cs = Object.prototype.propertyIsEnumerable, T = (s, e, t) => e in s ? is(s, e, { enumerable: true, configurable: true, writable: true, value: t }) : s[e] = t, ee = (s, e) => {
  for (var t in e || (e = {})) as.call(e, t) && T(s, t, e[t]);
  if (Ue) for (var t of Ue(e)) cs.call(e, t) && T(s, t, e[t]);
  return s;
}, te = (s, e) => rs(s, ns(e)), I = (s, e, t) => T(s, typeof e != "symbol" ? e + "" : e, t);
class os {
  constructor(e) {
    I(this, "name", "eip155"), I(this, "client"), I(this, "chainId"), I(this, "namespace"), I(this, "httpProviders"), I(this, "events"), I(this, "storage"), this.namespace = e.namespace, this.events = h("events"), this.client = h("client"), this.httpProviders = this.createHttpProviders(), this.chainId = parseInt(this.getDefaultChain()), this.storage = re.getStorage(this.client.core.storage);
  }
  async request(e) {
    switch (e.request.method) {
      case "eth_requestAccounts":
        return this.getAccounts();
      case "eth_accounts":
        return this.getAccounts();
      case "wallet_switchEthereumChain":
        return await this.handleSwitchChain(e);
      case "eth_chainId":
        return parseInt(this.getDefaultChain());
      case "wallet_getCapabilities":
        return await this.getCapabilities(e);
      case "wallet_getCallsStatus":
        return await this.getCallStatus(e);
      case "wallet_sendCalls":
        return await this.sendCalls(e);
    }
    return this.namespace.methods.includes(e.request.method) ? await this.client.request(e) : this.getHttpProvider().request(e.request);
  }
  updateNamespace(e) {
    this.namespace = Object.assign(this.namespace, e);
  }
  setDefaultChain(e, t) {
    this.httpProviders[e] || this.setHttpProvider(parseInt(e), t), this.chainId = parseInt(e), this.events.emit(m.DEFAULT_CHAIN_CHANGED, `${this.name}:${e}`);
  }
  requestAccounts() {
    return this.getAccounts();
  }
  getDefaultChain() {
    if (this.chainId) return this.chainId.toString();
    if (this.namespace.defaultChain) return this.namespace.defaultChain;
    const e = this.namespace.chains[0];
    if (!e) throw new Error("ChainId not found");
    return e.split(":")[1];
  }
  createHttpProvider(e, t) {
    const i = t || f2(`${this.name}:${e}`, this.namespace, this.client.core.projectId);
    if (!i) throw new Error(`No RPC url provided for chainId: ${e}`);
    return new o$1(new f$1(i, h("disableProviderPing")));
  }
  setHttpProvider(e, t) {
    const i = this.createHttpProvider(e, t);
    i && (this.httpProviders[e] = i);
  }
  createHttpProviders() {
    const e = {};
    return this.namespace.chains.forEach((t) => {
      var i;
      const n = parseInt(b(t));
      e[n] = this.createHttpProvider(n, (i = this.namespace.rpcMap) == null ? void 0 : i[t]);
    }), e;
  }
  getAccounts() {
    const e = this.namespace.accounts;
    return e ? [...new Set(e.filter((t) => t.split(":")[1] === this.chainId.toString()).map((t) => t.split(":")[2]))] : [];
  }
  getHttpProvider(e) {
    const t = e || this.chainId;
    return this.httpProviders[t] || (this.httpProviders = te(ee({}, this.httpProviders), { [t]: this.createHttpProvider(t) }), this.httpProviders[t]);
  }
  async handleSwitchChain(e) {
    var t, i;
    let n = e.request.params ? (t = e.request.params[0]) == null ? void 0 : t.chainId : "0x0";
    n = n.startsWith("0x") ? n : `0x${n}`;
    const a = parseInt(n, 16);
    if (this.isChainApproved(a)) this.setDefaultChain(`${a}`);
    else if (this.namespace.methods.includes("wallet_switchEthereumChain")) await this.client.request({ topic: e.topic, request: { method: e.request.method, params: [{ chainId: n }] }, chainId: (i = this.namespace.chains) == null ? void 0 : i[0] }), this.setDefaultChain(`${a}`);
    else throw new Error(`Failed to switch to chain 'eip155:${a}'. The chain is not approved or the wallet does not support 'wallet_switchEthereumChain' method.`);
    return null;
  }
  isChainApproved(e) {
    return this.namespace.chains.includes(`${this.name}:${e}`);
  }
  async getCapabilities(e) {
    var t, i, n, a, r;
    const c2 = (i = (t = e.request) == null ? void 0 : t.params) == null ? void 0 : i[0], o2 = ((a = (n = e.request) == null ? void 0 : n.params) == null ? void 0 : a[1]) || [];
    if (!c2) throw new Error("Missing address parameter in `wallet_getCapabilities` request");
    const d2 = this.client.session.get(e.topic), u = ((r = d2?.sessionProperties) == null ? void 0 : r.capabilities) || {}, p2 = `${c2}${o2.join(",")}`, w2 = u?.[p2];
    if (w2) return w2;
    let l2;
    try {
      l2 = xt(d2, c2, o2);
    } catch (z) {
      console.warn("Failed to extract capabilities from session", z);
    }
    if (l2) return l2;
    const ne = await this.client.request(e);
    try {
      await this.client.session.update(e.topic, { sessionProperties: te(ee({}, d2.sessionProperties || {}), { capabilities: te(ee({}, u || {}), { [p2]: ne }) }) });
    } catch (z) {
      console.warn("Failed to update session with capabilities", z);
    }
    return ne;
  }
  async getCallStatus(e) {
    var t, i, n;
    const a = this.client.session.get(e.topic), r = (t = a.sessionProperties) == null ? void 0 : t.bundler_name;
    if (r) {
      const d2 = this.getBundlerUrl(e.chainId, r);
      try {
        return await this.getUserOperationReceipt(d2, e);
      } catch (u) {
        console.warn("Failed to fetch call status from bundler", u, d2);
      }
    }
    const c2 = (i = a.sessionProperties) == null ? void 0 : i.bundler_url;
    if (c2) try {
      return await this.getUserOperationReceipt(c2, e);
    } catch (d2) {
      console.warn("Failed to fetch call status from custom bundler", d2, c2);
    }
    const o2 = await Tt({ resultId: (n = e.request.params) == null ? void 0 : n[0], storage: this.storage });
    if (o2) try {
      return await Yt(o2, this.getHttpProvider.bind(this));
    } catch (d2) {
      console.warn("Failed to fetch call status from stored send calls", d2, o2);
    }
    if (this.namespace.methods.includes(e.request.method)) return await this.client.request(e);
    throw new Error("Fetching call status not approved by the wallet.");
  }
  async getUserOperationReceipt(e, t) {
    var i;
    const n = new URL(e), a = await fetch(n, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(formatJsonRpcRequest("eth_getUserOperationReceipt", [(i = t.request.params) == null ? void 0 : i[0]])) });
    if (!a.ok) throw new Error(`Failed to fetch user operation receipt - ${a.status}`);
    return await a.json();
  }
  getBundlerUrl(e, t) {
    return `${Ye}?projectId=${this.client.core.projectId}&chainId=${e}&bundler=${t}`;
  }
  async sendCalls(e) {
    var t, i, n;
    const a = await this.client.request(e), r = (t = e.request.params) == null ? void 0 : t[0], c2 = a?.id, o2 = a?.capabilities || {}, d2 = (i = o2?.caip345) == null ? void 0 : i.caip2, u = (n = o2?.caip345) == null ? void 0 : n.transactionHashes;
    return !c2 || !d2 || !(u != null && u.length) || await Qt({ sendCalls: { request: r, result: a }, storage: this.storage }), a;
  }
}
var hs = Object.defineProperty, ps = (s, e, t) => e in s ? hs(s, e, { enumerable: true, configurable: true, writable: true, value: t }) : s[e] = t, A = (s, e, t) => ps(s, typeof e != "symbol" ? e + "" : e, t);
class ds {
  constructor(e) {
    A(this, "name", "solana"), A(this, "client"), A(this, "httpProviders"), A(this, "events"), A(this, "namespace"), A(this, "chainId"), this.namespace = e.namespace, this.events = h("events"), this.client = h("client"), this.chainId = this.getDefaultChain(), this.httpProviders = this.createHttpProviders();
  }
  updateNamespace(e) {
    this.namespace = Object.assign(this.namespace, e);
  }
  requestAccounts() {
    return this.getAccounts();
  }
  request(e) {
    return this.namespace.methods.includes(e.request.method) ? this.client.request(e) : this.getHttpProvider().request(e.request);
  }
  setDefaultChain(e, t) {
    this.httpProviders[e] || this.setHttpProvider(e, t), this.chainId = e, this.events.emit(m.DEFAULT_CHAIN_CHANGED, `${this.name}:${e}`);
  }
  getDefaultChain() {
    if (this.chainId) return this.chainId;
    if (this.namespace.defaultChain) return this.namespace.defaultChain;
    const e = this.namespace.chains[0];
    if (!e) throw new Error("ChainId not found");
    return e.split(":")[1];
  }
  getAccounts() {
    const e = this.namespace.accounts;
    return e ? [...new Set(e.filter((t) => t.split(":")[1] === this.chainId.toString()).map((t) => t.split(":")[2]))] : [];
  }
  createHttpProviders() {
    const e = {};
    return this.namespace.chains.forEach((t) => {
      var i;
      const n = b(t);
      e[n] = this.createHttpProvider(n, (i = this.namespace.rpcMap) == null ? void 0 : i[t]);
    }), e;
  }
  getHttpProvider() {
    const e = `${this.name}:${this.chainId}`, t = this.httpProviders[e];
    if (typeof t > "u") throw new Error(`JSON-RPC provider for ${e} not found`);
    return t;
  }
  setHttpProvider(e, t) {
    const i = this.createHttpProvider(e, t);
    i && (this.httpProviders[e] = i);
  }
  createHttpProvider(e, t) {
    const i = t || f2(e, this.namespace, this.client.core.projectId);
    if (!i) throw new Error(`No RPC url provided for chainId: ${e}`);
    return new o$1(new f$1(i, h("disableProviderPing")));
  }
}
var us = Object.defineProperty, ls = (s, e, t) => e in s ? us(s, e, { enumerable: true, configurable: true, writable: true, value: t }) : s[e] = t, E = (s, e, t) => ls(s, typeof e != "symbol" ? e + "" : e, t);
class fs {
  constructor(e) {
    E(this, "name", "cosmos"), E(this, "client"), E(this, "httpProviders"), E(this, "events"), E(this, "namespace"), E(this, "chainId"), this.namespace = e.namespace, this.events = h("events"), this.client = h("client"), this.chainId = this.getDefaultChain(), this.httpProviders = this.createHttpProviders();
  }
  updateNamespace(e) {
    this.namespace = Object.assign(this.namespace, e);
  }
  requestAccounts() {
    return this.getAccounts();
  }
  getDefaultChain() {
    if (this.chainId) return this.chainId;
    if (this.namespace.defaultChain) return this.namespace.defaultChain;
    const e = this.namespace.chains[0];
    if (!e) throw new Error("ChainId not found");
    return e.split(":")[1];
  }
  request(e) {
    return this.namespace.methods.includes(e.request.method) ? this.client.request(e) : this.getHttpProvider().request(e.request);
  }
  setDefaultChain(e, t) {
    this.httpProviders[e] || this.setHttpProvider(e, t), this.chainId = e, this.events.emit(m.DEFAULT_CHAIN_CHANGED, `${this.name}:${this.chainId}`);
  }
  getAccounts() {
    const e = this.namespace.accounts;
    return e ? [...new Set(e.filter((t) => t.split(":")[1] === this.chainId.toString()).map((t) => t.split(":")[2]))] : [];
  }
  createHttpProviders() {
    const e = {};
    return this.namespace.chains.forEach((t) => {
      var i;
      const n = b(t);
      e[n] = this.createHttpProvider(n, (i = this.namespace.rpcMap) == null ? void 0 : i[t]);
    }), e;
  }
  getHttpProvider() {
    const e = `${this.name}:${this.chainId}`, t = this.httpProviders[e];
    if (typeof t > "u") throw new Error(`JSON-RPC provider for ${e} not found`);
    return t;
  }
  setHttpProvider(e, t) {
    const i = this.createHttpProvider(e, t);
    i && (this.httpProviders[e] = i);
  }
  createHttpProvider(e, t) {
    const i = t || f2(e, this.namespace, this.client.core.projectId);
    if (!i) throw new Error(`No RPC url provided for chainId: ${e}`);
    return new o$1(new f$1(i, h("disableProviderPing")));
  }
}
var ms = Object.defineProperty, vs = (s, e, t) => e in s ? ms(s, e, { enumerable: true, configurable: true, writable: true, value: t }) : s[e] = t, H = (s, e, t) => vs(s, typeof e != "symbol" ? e + "" : e, t);
class gs {
  constructor(e) {
    H(this, "name", "algorand"), H(this, "client"), H(this, "httpProviders"), H(this, "events"), H(this, "namespace"), H(this, "chainId"), this.namespace = e.namespace, this.events = h("events"), this.client = h("client"), this.chainId = this.getDefaultChain(), this.httpProviders = this.createHttpProviders();
  }
  updateNamespace(e) {
    this.namespace = Object.assign(this.namespace, e);
  }
  requestAccounts() {
    return this.getAccounts();
  }
  request(e) {
    return this.namespace.methods.includes(e.request.method) ? this.client.request(e) : this.getHttpProvider().request(e.request);
  }
  setDefaultChain(e, t) {
    if (!this.httpProviders[e]) {
      const i = t || f2(`${this.name}:${e}`, this.namespace, this.client.core.projectId);
      if (!i) throw new Error(`No RPC url provided for chainId: ${e}`);
      this.setHttpProvider(e, i);
    }
    this.chainId = e, this.events.emit(m.DEFAULT_CHAIN_CHANGED, `${this.name}:${this.chainId}`);
  }
  getDefaultChain() {
    if (this.chainId) return this.chainId;
    if (this.namespace.defaultChain) return this.namespace.defaultChain;
    const e = this.namespace.chains[0];
    if (!e) throw new Error("ChainId not found");
    return e.split(":")[1];
  }
  getAccounts() {
    const e = this.namespace.accounts;
    return e ? [...new Set(e.filter((t) => t.split(":")[1] === this.chainId.toString()).map((t) => t.split(":")[2]))] : [];
  }
  createHttpProviders() {
    const e = {};
    return this.namespace.chains.forEach((t) => {
      var i;
      e[t] = this.createHttpProvider(t, (i = this.namespace.rpcMap) == null ? void 0 : i[t]);
    }), e;
  }
  getHttpProvider() {
    const e = `${this.name}:${this.chainId}`, t = this.httpProviders[e];
    if (typeof t > "u") throw new Error(`JSON-RPC provider for ${e} not found`);
    return t;
  }
  setHttpProvider(e, t) {
    const i = this.createHttpProvider(e, t);
    i && (this.httpProviders[e] = i);
  }
  createHttpProvider(e, t) {
    const i = t || f2(e, this.namespace, this.client.core.projectId);
    return typeof i > "u" ? void 0 : new o$1(new f$1(i, h("disableProviderPing")));
  }
}
var Ps = Object.defineProperty, ws = (s, e, t) => e in s ? Ps(s, e, { enumerable: true, configurable: true, writable: true, value: t }) : s[e] = t, S = (s, e, t) => ws(s, typeof e != "symbol" ? e + "" : e, t);
class ys {
  constructor(e) {
    S(this, "name", "cip34"), S(this, "client"), S(this, "httpProviders"), S(this, "events"), S(this, "namespace"), S(this, "chainId"), this.namespace = e.namespace, this.events = h("events"), this.client = h("client"), this.chainId = this.getDefaultChain(), this.httpProviders = this.createHttpProviders();
  }
  updateNamespace(e) {
    this.namespace = Object.assign(this.namespace, e);
  }
  requestAccounts() {
    return this.getAccounts();
  }
  getDefaultChain() {
    if (this.chainId) return this.chainId;
    if (this.namespace.defaultChain) return this.namespace.defaultChain;
    const e = this.namespace.chains[0];
    if (!e) throw new Error("ChainId not found");
    return e.split(":")[1];
  }
  request(e) {
    return this.namespace.methods.includes(e.request.method) ? this.client.request(e) : this.getHttpProvider().request(e.request);
  }
  setDefaultChain(e, t) {
    this.httpProviders[e] || this.setHttpProvider(e, t), this.chainId = e, this.events.emit(m.DEFAULT_CHAIN_CHANGED, `${this.name}:${this.chainId}`);
  }
  getAccounts() {
    const e = this.namespace.accounts;
    return e ? [...new Set(e.filter((t) => t.split(":")[1] === this.chainId.toString()).map((t) => t.split(":")[2]))] : [];
  }
  createHttpProviders() {
    const e = {};
    return this.namespace.chains.forEach((t) => {
      const i = this.getCardanoRPCUrl(t), n = b(t);
      e[n] = this.createHttpProvider(n, i);
    }), e;
  }
  getHttpProvider() {
    const e = `${this.name}:${this.chainId}`, t = this.httpProviders[e];
    if (typeof t > "u") throw new Error(`JSON-RPC provider for ${e} not found`);
    return t;
  }
  getCardanoRPCUrl(e) {
    const t = this.namespace.rpcMap;
    if (t) return t[e];
  }
  setHttpProvider(e, t) {
    const i = this.createHttpProvider(e, t);
    i && (this.httpProviders[e] = i);
  }
  createHttpProvider(e, t) {
    const i = t || this.getCardanoRPCUrl(e);
    if (!i) throw new Error(`No RPC url provided for chainId: ${e}`);
    return new o$1(new f$1(i, h("disableProviderPing")));
  }
}
var bs = Object.defineProperty, Is = (s, e, t) => e in s ? bs(s, e, { enumerable: true, configurable: true, writable: true, value: t }) : s[e] = t, N = (s, e, t) => Is(s, typeof e != "symbol" ? e + "" : e, t);
class $s {
  constructor(e) {
    N(this, "name", "elrond"), N(this, "client"), N(this, "httpProviders"), N(this, "events"), N(this, "namespace"), N(this, "chainId"), this.namespace = e.namespace, this.events = h("events"), this.client = h("client"), this.chainId = this.getDefaultChain(), this.httpProviders = this.createHttpProviders();
  }
  updateNamespace(e) {
    this.namespace = Object.assign(this.namespace, e);
  }
  requestAccounts() {
    return this.getAccounts();
  }
  request(e) {
    return this.namespace.methods.includes(e.request.method) ? this.client.request(e) : this.getHttpProvider().request(e.request);
  }
  setDefaultChain(e, t) {
    this.httpProviders[e] || this.setHttpProvider(e, t), this.chainId = e, this.events.emit(m.DEFAULT_CHAIN_CHANGED, `${this.name}:${e}`);
  }
  getDefaultChain() {
    if (this.chainId) return this.chainId;
    if (this.namespace.defaultChain) return this.namespace.defaultChain;
    const e = this.namespace.chains[0];
    if (!e) throw new Error("ChainId not found");
    return e.split(":")[1];
  }
  getAccounts() {
    const e = this.namespace.accounts;
    return e ? [...new Set(e.filter((t) => t.split(":")[1] === this.chainId.toString()).map((t) => t.split(":")[2]))] : [];
  }
  createHttpProviders() {
    const e = {};
    return this.namespace.chains.forEach((t) => {
      var i;
      const n = b(t);
      e[n] = this.createHttpProvider(n, (i = this.namespace.rpcMap) == null ? void 0 : i[t]);
    }), e;
  }
  getHttpProvider() {
    const e = `${this.name}:${this.chainId}`, t = this.httpProviders[e];
    if (typeof t > "u") throw new Error(`JSON-RPC provider for ${e} not found`);
    return t;
  }
  setHttpProvider(e, t) {
    const i = this.createHttpProvider(e, t);
    i && (this.httpProviders[e] = i);
  }
  createHttpProvider(e, t) {
    const i = t || f2(e, this.namespace, this.client.core.projectId);
    if (!i) throw new Error(`No RPC url provided for chainId: ${e}`);
    return new o$1(new f$1(i, h("disableProviderPing")));
  }
}
var Os = Object.defineProperty, Cs = (s, e, t) => e in s ? Os(s, e, { enumerable: true, configurable: true, writable: true, value: t }) : s[e] = t, q = (s, e, t) => Cs(s, typeof e != "symbol" ? e + "" : e, t);
class As {
  constructor(e) {
    q(this, "name", "multiversx"), q(this, "client"), q(this, "httpProviders"), q(this, "events"), q(this, "namespace"), q(this, "chainId"), this.namespace = e.namespace, this.events = h("events"), this.client = h("client"), this.chainId = this.getDefaultChain(), this.httpProviders = this.createHttpProviders();
  }
  updateNamespace(e) {
    this.namespace = Object.assign(this.namespace, e);
  }
  requestAccounts() {
    return this.getAccounts();
  }
  request(e) {
    return this.namespace.methods.includes(e.request.method) ? this.client.request(e) : this.getHttpProvider().request(e.request);
  }
  setDefaultChain(e, t) {
    this.httpProviders[e] || this.setHttpProvider(e, t), this.chainId = e, this.events.emit(m.DEFAULT_CHAIN_CHANGED, `${this.name}:${e}`);
  }
  getDefaultChain() {
    if (this.chainId) return this.chainId;
    if (this.namespace.defaultChain) return this.namespace.defaultChain;
    const e = this.namespace.chains[0];
    if (!e) throw new Error("ChainId not found");
    return e.split(":")[1];
  }
  getAccounts() {
    const e = this.namespace.accounts;
    return e ? [...new Set(e.filter((t) => t.split(":")[1] === this.chainId.toString()).map((t) => t.split(":")[2]))] : [];
  }
  createHttpProviders() {
    const e = {};
    return this.namespace.chains.forEach((t) => {
      var i;
      const n = b(t);
      e[n] = this.createHttpProvider(n, (i = this.namespace.rpcMap) == null ? void 0 : i[t]);
    }), e;
  }
  getHttpProvider() {
    const e = `${this.name}:${this.chainId}`, t = this.httpProviders[e];
    if (typeof t > "u") throw new Error(`JSON-RPC provider for ${e} not found`);
    return t;
  }
  setHttpProvider(e, t) {
    const i = this.createHttpProvider(e, t);
    i && (this.httpProviders[e] = i);
  }
  createHttpProvider(e, t) {
    const i = t || f2(e, this.namespace, this.client.core.projectId);
    if (!i) throw new Error(`No RPC url provided for chainId: ${e}`);
    return new o$1(new f$1(i, h("disableProviderPing")));
  }
}
var Es = Object.defineProperty, Hs = (s, e, t) => e in s ? Es(s, e, { enumerable: true, configurable: true, writable: true, value: t }) : s[e] = t, D = (s, e, t) => Hs(s, typeof e != "symbol" ? e + "" : e, t);
class Ss {
  constructor(e) {
    D(this, "name", "near"), D(this, "client"), D(this, "httpProviders"), D(this, "events"), D(this, "namespace"), D(this, "chainId"), this.namespace = e.namespace, this.events = h("events"), this.client = h("client"), this.chainId = this.getDefaultChain(), this.httpProviders = this.createHttpProviders();
  }
  updateNamespace(e) {
    this.namespace = Object.assign(this.namespace, e);
  }
  requestAccounts() {
    return this.getAccounts();
  }
  getDefaultChain() {
    if (this.chainId) return this.chainId;
    if (this.namespace.defaultChain) return this.namespace.defaultChain;
    const e = this.namespace.chains[0];
    if (!e) throw new Error("ChainId not found");
    return e.split(":")[1];
  }
  request(e) {
    return this.namespace.methods.includes(e.request.method) ? this.client.request(e) : this.getHttpProvider().request(e.request);
  }
  setDefaultChain(e, t) {
    if (this.chainId = e, !this.httpProviders[e]) {
      const i = t || f2(`${this.name}:${e}`, this.namespace);
      if (!i) throw new Error(`No RPC url provided for chainId: ${e}`);
      this.setHttpProvider(e, i);
    }
    this.events.emit(m.DEFAULT_CHAIN_CHANGED, `${this.name}:${this.chainId}`);
  }
  getAccounts() {
    const e = this.namespace.accounts;
    return e ? e.filter((t) => t.split(":")[1] === this.chainId.toString()).map((t) => t.split(":")[2]) || [] : [];
  }
  createHttpProviders() {
    const e = {};
    return this.namespace.chains.forEach((t) => {
      var i;
      e[t] = this.createHttpProvider(t, (i = this.namespace.rpcMap) == null ? void 0 : i[t]);
    }), e;
  }
  getHttpProvider() {
    const e = `${this.name}:${this.chainId}`, t = this.httpProviders[e];
    if (typeof t > "u") throw new Error(`JSON-RPC provider for ${e} not found`);
    return t;
  }
  setHttpProvider(e, t) {
    const i = this.createHttpProvider(e, t);
    i && (this.httpProviders[e] = i);
  }
  createHttpProvider(e, t) {
    const i = t || f2(e, this.namespace);
    return typeof i > "u" ? void 0 : new o$1(new f$1(i, h("disableProviderPing")));
  }
}
var Ns = Object.defineProperty, qs = (s, e, t) => e in s ? Ns(s, e, { enumerable: true, configurable: true, writable: true, value: t }) : s[e] = t, j = (s, e, t) => qs(s, typeof e != "symbol" ? e + "" : e, t);
class Ds {
  constructor(e) {
    j(this, "name", "tezos"), j(this, "client"), j(this, "httpProviders"), j(this, "events"), j(this, "namespace"), j(this, "chainId"), this.namespace = e.namespace, this.events = h("events"), this.client = h("client"), this.chainId = this.getDefaultChain(), this.httpProviders = this.createHttpProviders();
  }
  updateNamespace(e) {
    this.namespace = Object.assign(this.namespace, e);
  }
  requestAccounts() {
    return this.getAccounts();
  }
  getDefaultChain() {
    if (this.chainId) return this.chainId;
    if (this.namespace.defaultChain) return this.namespace.defaultChain;
    const e = this.namespace.chains[0];
    if (!e) throw new Error("ChainId not found");
    return e.split(":")[1];
  }
  request(e) {
    return this.namespace.methods.includes(e.request.method) ? this.client.request(e) : this.getHttpProvider().request(e.request);
  }
  setDefaultChain(e, t) {
    if (this.chainId = e, !this.httpProviders[e]) {
      const i = t || f2(`${this.name}:${e}`, this.namespace);
      if (!i) throw new Error(`No RPC url provided for chainId: ${e}`);
      this.setHttpProvider(e, i);
    }
    this.events.emit(m.DEFAULT_CHAIN_CHANGED, `${this.name}:${this.chainId}`);
  }
  getAccounts() {
    const e = this.namespace.accounts;
    return e ? e.filter((t) => t.split(":")[1] === this.chainId.toString()).map((t) => t.split(":")[2]) || [] : [];
  }
  createHttpProviders() {
    const e = {};
    return this.namespace.chains.forEach((t) => {
      e[t] = this.createHttpProvider(t);
    }), e;
  }
  getHttpProvider() {
    const e = `${this.name}:${this.chainId}`, t = this.httpProviders[e];
    if (typeof t > "u") throw new Error(`JSON-RPC provider for ${e} not found`);
    return t;
  }
  setHttpProvider(e, t) {
    const i = this.createHttpProvider(e, t);
    i && (this.httpProviders[e] = i);
  }
  createHttpProvider(e, t) {
    const i = t || f2(e, this.namespace);
    return typeof i > "u" ? void 0 : new o$1(new f$1(i));
  }
}
var js = Object.defineProperty, Rs = (s, e, t) => e in s ? js(s, e, { enumerable: true, configurable: true, writable: true, value: t }) : s[e] = t, R = (s, e, t) => Rs(s, typeof e != "symbol" ? e + "" : e, t);
class _s {
  constructor(e) {
    R(this, "name", ue), R(this, "client"), R(this, "httpProviders"), R(this, "events"), R(this, "namespace"), R(this, "chainId"), this.namespace = e.namespace, this.events = h("events"), this.client = h("client"), this.chainId = this.getDefaultChain(), this.name = this.getNamespaceName(), this.httpProviders = this.createHttpProviders();
  }
  updateNamespace(e) {
    this.namespace.chains = [...new Set((this.namespace.chains || []).concat(e.chains || []))], this.namespace.accounts = [...new Set((this.namespace.accounts || []).concat(e.accounts || []))], this.namespace.methods = [...new Set((this.namespace.methods || []).concat(e.methods || []))], this.namespace.events = [...new Set((this.namespace.events || []).concat(e.events || []))], this.httpProviders = this.createHttpProviders();
  }
  requestAccounts() {
    return this.getAccounts();
  }
  request(e) {
    return this.namespace.methods.includes(e.request.method) ? this.client.request(e) : this.getHttpProvider(e.chainId).request(e.request);
  }
  setDefaultChain(e, t) {
    this.httpProviders[e] || this.setHttpProvider(e, t), this.chainId = e, this.events.emit(m.DEFAULT_CHAIN_CHANGED, `${this.name}:${e}`);
  }
  getDefaultChain() {
    if (this.chainId) return this.chainId;
    if (this.namespace.defaultChain) return this.namespace.defaultChain;
    const e = this.namespace.chains[0];
    if (!e) throw new Error("ChainId not found");
    return e.split(":")[1];
  }
  getNamespaceName() {
    const e = this.namespace.chains[0];
    if (!e) throw new Error("ChainId not found");
    return Fe$1(e).namespace;
  }
  getAccounts() {
    const e = this.namespace.accounts;
    return e ? [...new Set(e.filter((t) => t.split(":")[1] === this.chainId.toString()).map((t) => t.split(":")[2]))] : [];
  }
  createHttpProviders() {
    var e, t;
    const i = {};
    return (t = (e = this.namespace) == null ? void 0 : e.accounts) == null || t.forEach((n) => {
      const a = Fe$1(n);
      i[a.reference] = this.createHttpProvider(n);
    }), i;
  }
  getHttpProvider(e) {
    const t = this.httpProviders[e];
    if (typeof t > "u") throw new Error(`JSON-RPC provider for ${e} not found`);
    return t;
  }
  setHttpProvider(e, t) {
    const i = this.createHttpProvider(e, t);
    i && (this.httpProviders[e] = i);
  }
  createHttpProvider(e, t) {
    const i = t || f2(e, this.namespace, this.client.core.projectId);
    if (!i) throw new Error(`No RPC url provided for chainId: ${e}`);
    return new o$1(new f$1(i, h("disableProviderPing")));
  }
}
var Fs = Object.defineProperty, Us = Object.defineProperties, xs = Object.getOwnPropertyDescriptors, xe = Object.getOwnPropertySymbols, Ls = Object.prototype.hasOwnProperty, Ms = Object.prototype.propertyIsEnumerable, se = (s, e, t) => e in s ? Fs(s, e, { enumerable: true, configurable: true, writable: true, value: t }) : s[e] = t, G = (s, e) => {
  for (var t in e || (e = {})) Ls.call(e, t) && se(s, t, e[t]);
  if (xe) for (var t of xe(e)) Ms.call(e, t) && se(s, t, e[t]);
  return s;
}, ie = (s, e) => Us(s, xs(e)), v = (s, e, t) => se(s, typeof e != "symbol" ? e + "" : e, t);
class J {
  constructor(e) {
    v(this, "client"), v(this, "namespaces"), v(this, "optionalNamespaces"), v(this, "sessionProperties"), v(this, "scopedProperties"), v(this, "events", new ke()), v(this, "rpcProviders", {}), v(this, "session"), v(this, "providerOpts"), v(this, "logger"), v(this, "uri"), v(this, "disableProviderPing", false), this.providerOpts = e, this.logger = typeof e?.logger < "u" && typeof e?.logger != "string" ? e.logger : Be(k({ level: e?.logger || pe })), this.disableProviderPing = e?.disableProviderPing || false;
  }
  static async init(e) {
    const t = new J(e);
    return await t.initialize(), t;
  }
  async request(e, t, i) {
    const [n, a] = this.validateChain(t);
    if (!this.session) throw new Error("Please call connect() before request()");
    return await this.getProvider(n).request({ request: G({}, e), chainId: `${n}:${a}`, topic: this.session.topic, expiry: i });
  }
  sendAsync(e, t, i, n) {
    const a = (/* @__PURE__ */ new Date()).getTime();
    this.request(e, i, n).then((r) => t(null, formatJsonRpcResult(a, r))).catch((r) => t(r, void 0));
  }
  async enable() {
    if (!this.client) throw new Error("Sign Client not initialized");
    return this.session || await this.connect({ namespaces: this.namespaces, optionalNamespaces: this.optionalNamespaces, sessionProperties: this.sessionProperties, scopedProperties: this.scopedProperties }), await this.requestAccounts();
  }
  async disconnect() {
    var e;
    if (!this.session) throw new Error("Please call connect() before enable()");
    await this.client.disconnect({ topic: (e = this.session) == null ? void 0 : e.topic, reason: Kt$1("USER_DISCONNECTED") }), await this.cleanup();
  }
  async connect(e) {
    if (!this.client) throw new Error("Sign Client not initialized");
    if (this.setNamespaces(e), this.cleanupPendingPairings(), !e.skipPairing) return await this.pair(e.pairingTopic);
  }
  async authenticate(e, t) {
    if (!this.client) throw new Error("Sign Client not initialized");
    this.setNamespaces(e), await this.cleanupPendingPairings();
    const { uri: i, response: n } = await this.client.authenticate(e, t);
    i && (this.uri = i, this.events.emit("display_uri", i));
    const a = await n();
    if (this.session = a.session, this.session) {
      const r = He(this.session.namespaces);
      this.namespaces = B(this.namespaces, r), await this.persist("namespaces", this.namespaces), this.onConnect();
    }
    return a;
  }
  on(e, t) {
    this.events.on(e, t);
  }
  once(e, t) {
    this.events.once(e, t);
  }
  removeListener(e, t) {
    this.events.removeListener(e, t);
  }
  off(e, t) {
    this.events.off(e, t);
  }
  get isWalletConnect() {
    return true;
  }
  async pair(e) {
    const { uri: t, approval: i } = await this.client.connect({ pairingTopic: e, requiredNamespaces: this.namespaces, optionalNamespaces: this.optionalNamespaces, sessionProperties: this.sessionProperties, scopedProperties: this.scopedProperties });
    t && (this.uri = t, this.events.emit("display_uri", t));
    const n = await i();
    this.session = n;
    const a = He(n.namespaces);
    return this.namespaces = B(this.namespaces, a), await this.persist("namespaces", this.namespaces), await this.persist("optionalNamespaces", this.optionalNamespaces), this.onConnect(), this.session;
  }
  setDefaultChain(e, t) {
    try {
      if (!this.session) return;
      const [i, n] = this.validateChain(e);
      this.getProvider(i).setDefaultChain(n, t);
    } catch (i) {
      if (!/Please call connect/.test(i.message)) throw i;
    }
  }
  async cleanupPendingPairings(e = {}) {
    try {
      this.logger.info("Cleaning up inactive pairings...");
      const t = this.client.pairing.getAll();
      if (!me$1(t)) return;
      for (const i of t) e.deletePairings ? this.client.core.expirer.set(i.topic, 0) : await this.client.core.relayer.subscriber.unsubscribe(i.topic);
      this.logger.info(`Inactive pairings cleared: ${t.length}`);
    } catch (t) {
      this.logger.warn("Failed to cleanup pending pairings", t);
    }
  }
  abortPairingAttempt() {
    this.logger.warn("abortPairingAttempt is deprecated. This is now a no-op.");
  }
  async checkStorage() {
    this.namespaces = await this.getFromStore("namespaces") || {}, this.optionalNamespaces = await this.getFromStore("optionalNamespaces") || {}, this.session && this.createProviders();
  }
  async initialize() {
    this.logger.trace("Initialized"), await this.createClient(), await this.checkStorage(), this.registerEventListeners();
  }
  async createClient() {
    var e, t;
    if (this.client = this.providerOpts.client || await fe$1.init({ core: this.providerOpts.core, logger: this.providerOpts.logger || pe, relayUrl: this.providerOpts.relayUrl || We, projectId: this.providerOpts.projectId, metadata: this.providerOpts.metadata, storageOptions: this.providerOpts.storageOptions, storage: this.providerOpts.storage, name: this.providerOpts.name, customStoragePrefix: this.providerOpts.customStoragePrefix, telemetryEnabled: this.providerOpts.telemetryEnabled }), this.providerOpts.session) try {
      this.session = this.client.session.get(this.providerOpts.session.topic);
    } catch (i) {
      throw this.logger.error("Failed to get session", i), new Error(`The provided session: ${(t = (e = this.providerOpts) == null ? void 0 : e.session) == null ? void 0 : t.topic} doesn't exist in the Sign client`);
    }
    else {
      const i = this.client.session.getAll();
      this.session = i[0];
    }
    this.logger.trace("SignClient Initialized");
  }
  createProviders() {
    if (!this.client) throw new Error("Sign Client not initialized");
    if (!this.session) throw new Error("Session not initialized. Please call connect() before enable()");
    const e = [...new Set(Object.keys(this.session.namespaces).map((t) => Yo(t)))];
    X("client", this.client), X("events", this.events), X("disableProviderPing", this.disableProviderPing), e.forEach((t) => {
      if (!this.session) return;
      const i = Nt(t, this.session);
      if (i?.length === 0) return;
      const n = Oe(i), a = B(this.namespaces, this.optionalNamespaces), r = ie(G({}, a[t]), { accounts: i, chains: n });
      switch (t) {
        case "eip155":
          this.rpcProviders[t] = new os({ namespace: r });
          break;
        case "algorand":
          this.rpcProviders[t] = new gs({ namespace: r });
          break;
        case "solana":
          this.rpcProviders[t] = new ds({ namespace: r });
          break;
        case "cosmos":
          this.rpcProviders[t] = new fs({ namespace: r });
          break;
        case "polkadot":
          this.rpcProviders[t] = new ss({ namespace: r });
          break;
        case "cip34":
          this.rpcProviders[t] = new ys({ namespace: r });
          break;
        case "elrond":
          this.rpcProviders[t] = new $s({ namespace: r });
          break;
        case "multiversx":
          this.rpcProviders[t] = new As({ namespace: r });
          break;
        case "near":
          this.rpcProviders[t] = new Ss({ namespace: r });
          break;
        case "tezos":
          this.rpcProviders[t] = new Ds({ namespace: r });
          break;
        default:
          this.rpcProviders[t] = new _s({ namespace: r });
      }
    });
  }
  registerEventListeners() {
    if (typeof this.client > "u") throw new Error("Sign Client is not initialized");
    this.client.on("session_ping", (e) => {
      var t;
      const { topic: i } = e;
      i === ((t = this.session) == null ? void 0 : t.topic) && this.events.emit("session_ping", e);
    }), this.client.on("session_event", (e) => {
      var t;
      const { params: i, topic: n } = e;
      if (n !== ((t = this.session) == null ? void 0 : t.topic)) return;
      const { event: a } = i;
      if (a.name === "accountsChanged") {
        const r = a.data;
        r && me$1(r) && this.events.emit("accountsChanged", r.map(Ee));
      } else if (a.name === "chainChanged") {
        const r = i.chainId, c2 = i.event.data, o2 = Yo(r), d2 = Y(r) !== Y(c2) ? `${o2}:${Y(c2)}` : r;
        this.onChainChanged(d2);
      } else this.events.emit(a.name, a.data);
      this.events.emit("session_event", e);
    }), this.client.on("session_update", ({ topic: e, params: t }) => {
      var i, n;
      if (e !== ((i = this.session) == null ? void 0 : i.topic)) return;
      const { namespaces: a } = t, r = (n = this.client) == null ? void 0 : n.session.get(e);
      this.session = ie(G({}, r), { namespaces: a }), this.onSessionUpdate(), this.events.emit("session_update", { topic: e, params: t });
    }), this.client.on("session_delete", async (e) => {
      var t;
      e.topic === ((t = this.session) == null ? void 0 : t.topic) && (await this.cleanup(), this.events.emit("session_delete", e), this.events.emit("disconnect", ie(G({}, Kt$1("USER_DISCONNECTED")), { data: e.topic })));
    }), this.on(m.DEFAULT_CHAIN_CHANGED, (e) => {
      this.onChainChanged(e, true);
    });
  }
  getProvider(e) {
    return this.rpcProviders[e] || this.rpcProviders[ue];
  }
  onSessionUpdate() {
    Object.keys(this.rpcProviders).forEach((e) => {
      var t;
      this.getProvider(e).updateNamespace((t = this.session) == null ? void 0 : t.namespaces[e]);
    });
  }
  setNamespaces(e) {
    const { namespaces: t = {}, optionalNamespaces: i = {}, sessionProperties: n, scopedProperties: a } = e;
    this.optionalNamespaces = B(t, i), this.sessionProperties = n, this.scopedProperties = a;
  }
  validateChain(e) {
    const [t, i] = e?.split(":") || ["", ""];
    if (!this.namespaces || !Object.keys(this.namespaces).length) return [t, i];
    if (t && !Object.keys(this.namespaces || {}).map((r) => Yo(r)).includes(t)) throw new Error(`Namespace '${t}' is not configured. Please call connect() first with namespace config.`);
    if (t && i) return [t, i];
    const n = Yo(Object.keys(this.namespaces)[0]), a = this.rpcProviders[n].getDefaultChain();
    return [n, a];
  }
  async requestAccounts() {
    const [e] = this.validateChain();
    return await this.getProvider(e).requestAccounts();
  }
  async onChainChanged(e, t = false) {
    if (!this.namespaces) return;
    const [i, n] = this.validateChain(e);
    if (!n) return;
    this.updateNamespaceChain(i, n);
    const a = this.getProvider(i).getDefaultChain();
    t ? (this.events.emit("chainChanged", n), this.emitAccountsChangedOnChainChange({ namespace: i, previousChainId: a, newChainId: e })) : this.getProvider(i).setDefaultChain(n), await this.persist("namespaces", this.namespaces);
  }
  emitAccountsChangedOnChainChange({ namespace: e, previousChainId: t, newChainId: i }) {
    var n, a;
    try {
      if (t === i) return;
      const r = (a = (n = this.session) == null ? void 0 : n.namespaces[e]) == null ? void 0 : a.accounts;
      if (!r) return;
      const c2 = r.filter((o2) => o2.includes(`${i}:`)).map(Ee);
      if (!me$1(c2)) return;
      this.events.emit("accountsChanged", c2);
    } catch (r) {
      this.logger.warn("Failed to emit accountsChanged on chain change", r);
    }
  }
  updateNamespaceChain(e, t) {
    if (!this.namespaces) return;
    const i = this.namespaces[e] ? e : `${e}:${t}`, n = { chains: [], methods: [], events: [], defaultChain: t };
    this.namespaces[i] ? this.namespaces[i] && (this.namespaces[i].defaultChain = t) : this.namespaces[i] = n;
  }
  onConnect() {
    this.createProviders(), this.events.emit("connect", { session: this.session });
  }
  async cleanup() {
    this.namespaces = void 0, this.optionalNamespaces = void 0, this.sessionProperties = void 0, await this.deleteFromStore("namespaces"), await this.deleteFromStore("optionalNamespaces"), await this.deleteFromStore("sessionProperties"), this.session = void 0, this.cleanupPendingPairings({ deletePairings: true }), await this.cleanupStorage();
  }
  async persist(e, t) {
    var i;
    const n = ((i = this.session) == null ? void 0 : i.topic) || "";
    await this.client.core.storage.setItem(`${x}/${e}${n}`, t);
  }
  async getFromStore(e) {
    var t;
    const i = ((t = this.session) == null ? void 0 : t.topic) || "";
    return await this.client.core.storage.getItem(`${x}/${e}${i}`);
  }
  async deleteFromStore(e) {
    var t;
    const i = ((t = this.session) == null ? void 0 : t.topic) || "";
    await this.client.core.storage.removeItem(`${x}/${e}${i}`);
  }
  async cleanupStorage() {
    var e;
    try {
      if (((e = this.client) == null ? void 0 : e.session.length) > 0) return;
      const t = await this.client.core.storage.getKeys();
      for (const i of t) i.startsWith(x) && await this.client.core.storage.removeItem(i);
    } catch (t) {
      this.logger.warn("Failed to cleanup storage", t);
    }
  }
}
const Bs = J;
export {
  Bs as UniversalProvider,
  J as default
};
