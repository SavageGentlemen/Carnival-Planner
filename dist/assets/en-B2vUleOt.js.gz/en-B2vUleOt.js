const en = {
  createPassword: {
    confirmation: "I have saved my password",
    failedToSetPassword: "Failed to set password",
    inputPlaceholder: "Enter your password",
    instruction: "Set a password for your account. You will need this password when connecting from a new device.",
    saveInstruction: "Make sure to save it",
    submitButton: "Set Password",
    title: "Create Password"
  },
  emailLoginScreen: {
    enterCodeSendTo: "Enter the verification code sent to",
    enterRecoveryCode: "Enter the recovery code emailed to you when you first signed up",
    failedToSendCode: "Failed to send verification code",
    invalidCode: "Invalid verification code",
    invalidCodeOrRecoveryCode: "Invalid verification code or Recovery code",
    newDeviceDetected: "New device detected",
    resendCode: "Resend verification code",
    sendingCode: "Sending verification code",
    title: "Sign in",
    verify: "Verify"
  },
  emailPlaceholder: "Email address",
  emailRequired: "Email address is required",
  enterPassword: {
    inputPlaceholder: "Enter your password",
    instruction: "Enter the password for your account",
    submitButton: "Verify",
    title: "Enter Password",
    wrongPassword: "Wrong password"
  },
  invalidEmail: "Invalid email address",
  invalidPhone: "Invalid phone number",
  linkWallet: "Link a Wallet",
  loginAsGuest: "Continue as guest",
  maxAccountsExceeded: "Maximum number of accounts exceeded. Please notify the app developer.",
  or: "or",
  passkey: "Passkey",
  phonePlaceholder: "Phone number",
  phoneRequired: "Phone number is required",
  signIn: "Sign in",
  signInWithApple: "Apple",
  signInWithDiscord: "Discord",
  signInWithEmail: "Sign in with Email",
  signInWithFacebook: "Facebook",
  signInWithGoogle: "Google",
  signInWithPhone: "Sign in with phone number",
  signInWithWallet: "Sign in with Wallet",
  socialLoginScreen: {
    failed: "Failed to sign in",
    instruction: "Sign into your account in the pop-up",
    retry: "Retry",
    title: "Sign in"
  },
  submitEmail: "Continue"
};
export {
  en as default
};
