const connectLocaleZh = {
  agreement: {
    and: "和",
    prefix: "连接即表示您同意",
    privacyPolicy: "隐私政策",
    termsOfService: "服务条款"
  },
  backupWallet: "备份钱包",
  buy: "购买",
  confirmInWallet: "在钱包中确认",
  connectAWallet: "连接钱包",
  connectedToSmartWallet: "智能钱包",
  connecting: "连接中",
  continueAsGuest: "以访客身份继续",
  copyAddress: "复制地址",
  currentNetwork: "当前网络",
  defaultButtonTitle: "连接",
  defaultModalTitle: "登录",
  disconnectWallet: "断开钱包连接",
  getStarted: "开始使用",
  goBackButton: "返回",
  guest: "访客",
  guestWalletWarning: "这是一个临时访客钱包。如果您不想失去访问权限，请备份钱包",
  id: "zh_CN",
  installed: "已安装",
  manageWallet: {
    connectAnApp: "连接应用",
    exportPrivateKey: "导出私钥",
    linkedProfiles: "已关联配置文件",
    linkProfile: "关联配置文件",
    title: "管理钱包"
  },
  networkSelector: {
    addCustomNetwork: "添加自定义网络",
    allNetworks: "全部",
    categoryLabel: {
      others: "所有网络",
      popular: "热门",
      recentlyUsed: "最近使用"
    },
    failedToSwitch: "网络切换失败",
    inputPlaceholder: "搜索网络或链 ID",
    loading: "加载中",
    mainnets: "主网",
    testnets: "测试网",
    title: "选择网络"
  },
  newToWallets: "刚接触钱包？",
  or: "或",
  passkeys: {
    linkPasskey: "添加通行密钥",
    title: "通行密钥"
  },
  payTransactions: "法币交易",
  personalWallet: "个人钱包",
  receive: "接收",
  receiveFundsScreen: {
    instruction: "复制地址以向此钱包发送资金",
    title: "接收资金"
  },
  recommended: "推荐",
  requestTestnetFunds: "申请测试网资金",
  send: "发送",
  sendFundsScreen: {
    amount: "金额",
    insufficientFunds: "余额不足",
    invalidAddress: "地址无效",
    noTokensFound: "未找到代币",
    searchToken: "搜索或粘贴代币地址",
    selectTokenTitle: "选择代币",
    sending: "发送中",
    sendTo: "发送到",
    submitButton: "发送",
    successMessage: "交易成功",
    title: "发送资金",
    token: "代币",
    transactionFailed: "交易失败",
    transactionRejected: "交易被拒绝"
  },
  signatureScreen: {
    instructionScreen: {
      disconnectWallet: "断开钱包连接",
      instruction: "请在您的钱包中签署消息请求以继续",
      signInButton: "登录",
      title: "登录"
    },
    signingScreen: {
      approveTransactionInSafe: "在 Safe 中批准交易",
      failedToSignIn: "登录失败",
      inProgress: "等待确认",
      prompt: "在您的钱包中签署签名请求",
      promptForSafe: "在您的钱包中签署签名请求并在 Safe 中批准交易",
      title: "登录中",
      tryAgain: "重试"
    }
  },
  signIn: "登录",
  smartWallet: "智能钱包",
  switchAccount: "切换账户",
  switchingNetwork: "网络切换中",
  switchNetwork: "切换网络",
  switchTo: "切换到",
  transactions: "交易",
  viewAllTransactions: "查看所有交易",
  viewFunds: {
    title: "查看资产",
    viewAssets: "查看资产",
    viewNFTs: "查看NFT资产",
    viewTokens: "查看代币"
  },
  walletTransactions: "钱包交易",
  welcomeScreen: {
    defaultSubtitle: "连接钱包以开始使用",
    defaultTitle: "您通往去中心化世界的门户"
  }
};
export {
  connectLocaleZh as default
};
