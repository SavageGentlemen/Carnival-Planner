const connectLocaleDe = {
  agreement: {
    and: "&",
    prefix: "Durch die Verbindung stimmst du diesen zu:",
    privacyPolicy: "Datenschutzrichtlinien",
    termsOfService: "Nutzungsbedingungen"
  },
  backupWallet: "Wallet sichern",
  buy: "Kaufen",
  confirmInWallet: "Im Wallet bestätigen",
  connectAWallet: "Wallet verbinden",
  connectedToSmartWallet: "Smart Account",
  connecting: "Anmelden",
  continueAsGuest: "Als Gast fortfahren",
  copyAddress: "Adresse kopieren",
  currentNetwork: "Aktuelles Netzwerk",
  defaultButtonTitle: "Wallet verbinden",
  defaultModalTitle: "Anmelden",
  disconnectWallet: "Wallet trennen",
  getStarted: "Loslegen",
  goBackButton: "Zurück",
  guest: "Gast",
  guestWalletWarning: "Dies ist ein temporäres Gast-Wallet. Sichere das Wallet, wenn du den Zugriff darauf nicht verlieren möchtest",
  id: "de_DE",
  installed: "Installiert",
  manageWallet: {
    connectAnApp: "App verbinden",
    exportPrivateKey: "PrivateKey exportieren",
    linkedProfiles: "Verknüpfte Profile",
    linkProfile: "Profil verknüpfen",
    title: "Wallet verwalten"
  },
  networkSelector: {
    addCustomNetwork: "Eigenes Netzwerk hinzufügen",
    allNetworks: "Alle",
    categoryLabel: {
      others: "Alle Netzwerke",
      popular: "Beliebt",
      recentlyUsed: "Zuletzt verwendet"
    },
    failedToSwitch: "Netzwerkwechsel fehlgeschlagen",
    inputPlaceholder: "Netzwerk oder Chain ID suchen",
    loading: "Laden",
    mainnets: "Mainnets",
    testnets: "Testnets",
    title: "Netzwerk auswählen"
  },
  newToWallets: `Was ist ein "Wallet"?`,
  or: "Oder",
  passkeys: {
    linkPasskey: "Passkey verknüpfen",
    title: "Passkeys"
  },
  payTransactions: "Fiat Transaktionen",
  personalWallet: "Persönliches Wallet",
  receive: "Empfangen",
  // Used in "Switch to <Wallet-Name>"
  receiveFundsScreen: {
    instruction: "Kopiere die Wallet-Adresse, um Geld an dieses Wallet zu senden",
    title: "Geld empfangen"
  },
  recommended: "Empfohlen",
  requestTestnetFunds: "Testnetz-Geld anfordern",
  send: "Senden",
  sendFundsScreen: {
    amount: "Betrag",
    insufficientFunds: "Nicht genügend Guthaben",
    invalidAddress: "Ungültige Adresse",
    noTokensFound: "Keine Token gefunden",
    searchToken: "Token suchen oder einfügen",
    selectTokenTitle: "Token auswählen",
    sending: "Sende",
    sendTo: "Senden an",
    submitButton: "Senden",
    successMessage: "Transaktion erfolgreich",
    title: "Geld senden",
    token: "Token",
    transactionFailed: "Transaktion fehlgeschlagen",
    transactionRejected: "Transaktion abgelehnt"
  },
  signatureScreen: {
    instructionScreen: {
      disconnectWallet: "Wallet trennen",
      instruction: "Signiere die Anmeldeanfrage in deinem Wallet",
      signInButton: "Anmelden",
      title: "Anmelden"
    },
    signingScreen: {
      approveTransactionInSafe: "Transaktion im Safe bestätigen",
      failedToSignIn: "Anmeldung fehlgeschlagen",
      inProgress: "Warte auf Bestätigung",
      prompt: "Signiere die Signaturanfrage in deinem Wallet",
      promptForSafe: "Signiere die Signaturanfrage in deinem Wallet, um fortzufahren",
      title: "Signaturanfrage",
      tryAgain: "Erneut versuchen"
    }
  },
  signIn: "Anmelden",
  smartWallet: "Smart Wallet",
  switchAccount: "Account wechseln",
  switchingNetwork: "Netzwerk wechseln",
  switchNetwork: "Netzwerk wechseln",
  switchTo: "Wechsle zu",
  transactions: "Transaktionen",
  viewAllTransactions: "Alle Transaktionen anzeigen",
  viewFunds: {
    title: "Guthaben anzeigen",
    viewAssets: "Assets anzeigen",
    viewNFTs: "NFTs anzeigen",
    viewTokens: "Tokens anzeigen"
  },
  walletTransactions: "Wallet Transaktionen",
  welcomeScreen: {
    defaultSubtitle: "Verbinde ein Wallet, um loszulegen",
    defaultTitle: "Dein Tor zur dezentralen Welt"
  }
};
export {
  connectLocaleDe as default
};
