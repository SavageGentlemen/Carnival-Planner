const connectLocaleRu = {
  agreement: {
    and: "и",
    prefix: "Подключаясь, вы соглашаетесь с",
    privacyPolicy: "Политикой конфиденциальности",
    termsOfService: "Условиями использования"
  },
  backupWallet: "Создать резервную копию кошелька",
  buy: "Купить",
  confirmInWallet: "Подтвердить в кошельке",
  connectAWallet: "Подключить кошелек",
  connectedToSmartWallet: "Смарт-аккаунт",
  connecting: "Подключение",
  continueAsGuest: "Продолжить как гость",
  copyAddress: "Скопировать адрес",
  currentNetwork: "Текущая сеть",
  defaultButtonTitle: "Подключиться",
  defaultModalTitle: "Войти",
  disconnectWallet: "Отсоединить кошелек",
  getStarted: "Начать",
  goBackButton: "Назад",
  guest: "Гость",
  guestWalletWarning: "Это временный гостевой кошелек. Создайте резервную копию, если не хотите потерять к нему доступ",
  id: "ru_RU",
  installed: "Установлено",
  manageWallet: {
    connectAnApp: "Подключить приложение",
    exportPrivateKey: "Экспортировать приватный ключ",
    linkedProfiles: "Привязанные профили",
    linkProfile: "Привязать профиль",
    title: "Управление кошельком"
  },
  networkSelector: {
    addCustomNetwork: "Добавить кастомную сеть",
    allNetworks: "Все",
    categoryLabel: {
      others: "Все сети",
      popular: "Популярные",
      recentlyUsed: "Недавно использованные"
    },
    failedToSwitch: "Не удалось сменить сеть",
    inputPlaceholder: "Поиск сети или Chain ID",
    loading: "Загрузка",
    mainnets: "Основные сети (мейннетс)",
    testnets: "Тестовые сети (тестнетс)",
    title: "Выбрать сеть"
  },
  newToWallets: "Новичок в кошельках?",
  or: "ИЛИ",
  passkeys: {
    linkPasskey: "Привязать ключ доступа",
    title: "Ключи доступа"
  },
  payTransactions: "Фиатные транзакции",
  personalWallet: "Личный кошелек",
  receive: "Получить",
  // Используется в "Switch to <Wallet-Name>>"
  receiveFundsScreen: {
    instruction: "Скопируйте адрес кошелька, чтобы отправить средства на этот кошелек",
    title: "Получить средства"
  },
  recommended: "Рекомендуется",
  requestTestnetFunds: "Запросить средства тестовой сети",
  send: "Отправить",
  sendFundsScreen: {
    amount: "Сумма",
    insufficientFunds: "Недостаточно средств",
    invalidAddress: "Недействительный адрес",
    noTokensFound: "Токены не найдены",
    searchToken: "Найти или вставить адрес токена",
    selectTokenTitle: "Выбрать токен",
    sending: "Отправка",
    sendTo: "Отправить на",
    submitButton: "Отправить",
    successMessage: "Транзакция успешно выполнена",
    title: "Отправить средства",
    token: "Токен",
    transactionFailed: "Транзакция не удалась",
    transactionRejected: "Транзакция отклонена"
  },
  signatureScreen: {
    instructionScreen: {
      disconnectWallet: "Отсоединить кошелек",
      instruction: "Пожалуйста, подпишите сообщение в кошельке, чтобы продолжить",
      signInButton: "Войти",
      title: "Войти"
    },
    signingScreen: {
      approveTransactionInSafe: "Подтвердить транзакцию в Safe",
      failedToSignIn: "Не удалось войти",
      inProgress: "Ожидание подтверждения",
      prompt: "Подпись запроса в вашем кошельке",
      promptForSafe: "Подпишите запрос в вашем кошельке и подтвердите транзакцию в Safe",
      title: "Вход",
      tryAgain: "Попробовать снова"
    }
  },
  signIn: "Войти",
  smartWallet: "Смарт-кошелек",
  switchAccount: "Сменить аккаунт",
  switchingNetwork: "Смена сети",
  switchNetwork: "Сменить сеть",
  switchTo: "Переключиться на",
  transactions: "Транзакции",
  viewAllTransactions: "Просмотреть все транзакции",
  viewFunds: {
    title: "Просмотр средств",
    viewAssets: "Просмотр активов",
    viewNFTs: "Просмотр NFTs",
    viewTokens: "Просмотр токенов"
  },
  walletTransactions: "Транзакции кошелька",
  welcomeScreen: {
    defaultSubtitle: "Подключите кошелек, чтобы начать",
    defaultTitle: "Ваш портал в мир децентрализации"
  }
};
export {
  connectLocaleRu as default
};
