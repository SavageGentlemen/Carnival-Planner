const es = {
  createPassword: {
    confirmation: "He guardado mi contraseña",
    failedToSetPassword: "Error al establecer la contraseña",
    inputPlaceholder: "Ingrese su contraseña",
    instruction: "Establezca una contraseña para su cuenta. Necesitará esta contraseña cuando se conecte desde un nuevo dispositivo.",
    saveInstruction: "Asegúrese de guardarla",
    submitButton: "Establecer contraseña",
    title: "Crear contraseña"
  },
  emailLoginScreen: {
    enterCodeSendTo: "Ingresa el código de verificación enviado a",
    enterRecoveryCode: "Ingresa el código de recuperación que se te envió por correo electrónico cuando te registraste por primera vez",
    failedToSendCode: "Error al enviar el código de verificación",
    invalidCode: "Código de verificación inválido",
    invalidCodeOrRecoveryCode: "Código de verificación o de recuperación inválido",
    newDeviceDetected: "Nuevo dispositivo detectado",
    resendCode: "Reenviar código de verificación",
    sendingCode: "Enviando código de verificación",
    title: "Iniciar sesión",
    verify: "Verificar"
  },
  emailPlaceholder: "Ingresa tu dirección de correo electrónico",
  emailRequired: "Se requiere dirección de correo electrónico",
  enterPassword: {
    inputPlaceholder: "Ingrese su contraseña",
    instruction: "Ingrese la contraseña de su cuenta",
    submitButton: "Verificar",
    title: "Ingrese la contraseña",
    wrongPassword: "Contraseña incorrecta"
  },
  invalidEmail: "Dirección de correo electrónico inválida",
  invalidPhone: "Número de teléfono inválido",
  linkWallet: "Vincular una billetera",
  loginAsGuest: "Inicia sesión como invitado",
  maxAccountsExceeded: "Número máximo de cuentas alcanzado",
  or: "O",
  passkey: "Clave de acceso",
  phonePlaceholder: "Ingresa tu número de teléfono",
  phoneRequired: "Se requiere número de teléfono",
  signIn: "Iniciar sesión",
  signInWithApple: "Iniciar sesión con Apple",
  signInWithDiscord: "Iniciar sesión con Discord",
  signInWithEmail: "Iniciar sesión con correo electrónico",
  signInWithFacebook: "Iniciar sesión con Facebook",
  signInWithGoogle: "Iniciar sesión con Google",
  signInWithPhone: "Iniciar sesión con número de teléfono",
  signInWithWallet: "Iniciar sesión con billetera",
  socialLoginScreen: {
    failed: "Error al iniciar sesión",
    instruction: "Inicie sesión en su cuenta en la ventana abierta",
    retry: "Reintentar",
    title: "Iniciar sesión"
  },
  submitEmail: "Continuar"
};
export {
  es as default
};
